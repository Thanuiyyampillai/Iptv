export interface Channel {
  id: string;
  name: string;
  logo: string;
  group: string;
  url: string;
  number: number;
}

export const parseM3U = (m3uContent: string): Channel[] => {
  const lines = m3uContent.split(/\r?\n/);
  const channels: Channel[] = [];
  let currentChannel: Partial<Channel> = {};
  let channelNumber = 1;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    if (line.startsWith('#EXTINF:')) {
      // Parse metadata
      const idMatch = line.match(/tvg-id="([^"]*)"/);
      const logoMatch = line.match(/tvg-logo="([^"]*)"/);
      const groupMatch = line.match(/group-title="([^"]*)"/);
      
      const nameParts = line.split(',');
      const name = nameParts.length > 1 ? nameParts[1].trim() : 'Unknown Channel';

      currentChannel = {
        id: idMatch ? idMatch[1] : `ch-${channelNumber}`,
        name,
        logo: logoMatch ? logoMatch[1] : '',
        group: groupMatch ? groupMatch[1] : 'Uncategorized',
        number: channelNumber,
      };
    } else if (!line.startsWith('#')) {
      // This is a URL line
      if (currentChannel.name) {
        currentChannel.url = line;
        channels.push(currentChannel as Channel);
        channelNumber++;
        currentChannel = {}; // Reset for next channel
      }
    }
  }

  return channels;
};
