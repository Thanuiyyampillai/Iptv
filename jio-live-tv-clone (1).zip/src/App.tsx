import React, { useState, useEffect, useCallback, useRef } from 'react';
import { VideoPlayer } from './components/VideoPlayer';
import { parseM3U, Channel } from './utils/m3uParser';
import { Tv, Volume2, VolumeX, Loader2, Info } from 'lucide-react';

const PLAYLIST_URL = 'https://tinyurl.com/amaze-tamil-local-tv';

export default function App() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [currentChannelIndex, setCurrentChannelIndex] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [osdVisible, setOsdVisible] = useState(false);
  const [inputNumber, setInputNumber] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [hasInteracted, setHasInteracted] = useState(false);
  
  const osdTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const inputTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const fetchPlaylist = async () => {
      try {
        setLoading(true);
        // We use a CORS proxy or fetch directly if CORS is allowed.
        // Since we are in a browser, we might need a proxy if the URL doesn't have CORS headers.
        // Let's try fetching directly first.
        const response = await fetch(PLAYLIST_URL);
        if (!response.ok) {
          throw new Error('Failed to fetch playlist');
        }
        const text = await response.text();
        const parsedChannels = parseM3U(text);
        if (parsedChannels.length > 0) {
          setChannels(parsedChannels);
          setCurrentChannelIndex(0);
        } else {
          setError('No channels found in the playlist.');
        }
      } catch (err) {
        console.error('Error fetching playlist:', err);
        // Fallback to a proxy if direct fetch fails
        try {
          const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(PLAYLIST_URL)}`;
          const response = await fetch(proxyUrl);
          const text = await response.text();
          const parsedChannels = parseM3U(text);
          if (parsedChannels.length > 0) {
            setChannels(parsedChannels);
            setCurrentChannelIndex(0);
          } else {
            setError('No channels found in the playlist.');
          }
        } catch (proxyErr) {
          setError('Failed to load channels. Please check your connection.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchPlaylist();
  }, []);

  const showOsd = useCallback(() => {
    setOsdVisible(true);
    if (osdTimeoutRef.current) {
      clearTimeout(osdTimeoutRef.current);
    }
    osdTimeoutRef.current = setTimeout(() => {
      setOsdVisible(false);
    }, 4000);
  }, []);

  const changeChannel = useCallback((direction: 'up' | 'down') => {
    if (channels.length === 0) return;
    
    setCurrentChannelIndex((prev) => {
      if (direction === 'up') {
        return prev < channels.length - 1 ? prev + 1 : 0;
      } else {
        return prev > 0 ? prev - 1 : channels.length - 1;
      }
    });
    showOsd();
  }, [channels.length, showOsd]);

  const jumpToChannel = useCallback((numberStr: string) => {
    const num = parseInt(numberStr, 10);
    if (isNaN(num)) return;
    
    const index = channels.findIndex(c => c.number === num);
    if (index !== -1) {
      setCurrentChannelIndex(index);
      showOsd();
    }
  }, [channels, showOsd]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Handle number inputs
      if (e.key >= '0' && e.key <= '9') {
        const newNumber = inputNumber + e.key;
        setInputNumber(newNumber);
        
        // Show OSD with the typed number
        setOsdVisible(true);
        
        if (inputTimeoutRef.current) {
          clearTimeout(inputTimeoutRef.current);
        }
        
        inputTimeoutRef.current = setTimeout(() => {
          jumpToChannel(newNumber);
          setInputNumber('');
          
          // Hide OSD after a delay
          if (osdTimeoutRef.current) {
            clearTimeout(osdTimeoutRef.current);
          }
          osdTimeoutRef.current = setTimeout(() => {
            setOsdVisible(false);
          }, 3000);
        }, 1500); // Wait 1.5s for more digits
        return;
      }

      // Handle channel up/down
      if (
        e.key === 'ArrowUp' || 
        e.key === '+' || 
        e.key === 'PageUp' || 
        e.key === 'ChannelUp' ||
        e.keyCode === 166 || // Android KEYCODE_CHANNEL_UP
        e.keyCode === 427    // Some smart TVs use 427 for Channel Up
      ) {
        changeChannel('up');
      } else if (
        e.key === 'ArrowDown' || 
        e.key === '-' || 
        e.key === 'PageDown' || 
        e.key === 'ChannelDown' ||
        e.keyCode === 167 || // Android KEYCODE_CHANNEL_DOWN
        e.keyCode === 428    // Some smart TVs use 428 for Channel Down
      ) {
        changeChannel('down');
      } else if (e.key === 'Enter' && inputNumber) {
        // Immediate jump if Enter is pressed
        if (inputTimeoutRef.current) clearTimeout(inputTimeoutRef.current);
        jumpToChannel(inputNumber);
        setInputNumber('');
      } else if (e.key === 'i' || e.key === 'I') {
        showOsd();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [changeChannel, inputNumber, jumpToChannel, showOsd]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-black text-white">
        <Loader2 className="w-12 h-12 animate-spin text-blue-500 mb-4" />
        <h1 className="text-2xl font-bold">Jio Live TV</h1>
        <p className="text-gray-400 mt-2">Loading Channels...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-black text-white">
        <Tv className="w-16 h-16 text-red-500 mb-4" />
        <h1 className="text-2xl font-bold">Error</h1>
        <p className="text-gray-400 mt-2">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-6 px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-full transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  if (!hasInteracted) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-black text-white">
        <Tv className="w-20 h-20 text-blue-500 mb-6" />
        <h1 className="text-4xl font-bold mb-8 tracking-tight">Jio Live TV</h1>
        <button 
          onClick={() => {
            setHasInteracted(true);
            showOsd();
          }}
          className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-xl font-semibold rounded-full transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(37,99,235,0.5)]"
        >
          Power On
        </button>
      </div>
    );
  }

  const currentChannel = channels[currentChannelIndex];

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden select-none">
      {/* Video Player */}
      {currentChannel ? (
        <VideoPlayer 
          src={currentChannel.url} 
          className="w-full h-full"
        />
      ) : (
        <div className="flex items-center justify-center h-full text-white">
          <p>No channel selected</p>
        </div>
      )}

      {/* OSD (On Screen Display) */}
      <div 
        className={`absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/90 via-black/60 to-transparent transition-opacity duration-500 ${
          osdVisible || inputNumber ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="max-w-5xl mx-auto flex items-end justify-between">
          <div className="flex items-center space-x-6">
            {/* Channel Logo */}
            <div className="w-24 h-24 bg-white/10 backdrop-blur-md rounded-2xl p-2 flex items-center justify-center border border-white/20 shadow-2xl">
              {!inputNumber && currentChannel?.logo ? (
                <img 
                  src={currentChannel.logo} 
                  alt={currentChannel.name} 
                  className="max-w-full max-h-full object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              ) : (
                <Tv className="w-12 h-12 text-white/50" />
              )}
            </div>
            
            {/* Channel Info */}
            <div className="text-white">
              <div className="flex items-baseline space-x-3">
                <span className="text-5xl font-bold tracking-tighter text-blue-400">
                  {inputNumber || currentChannel?.number}
                </span>
                <h2 className="text-3xl font-semibold tracking-tight">
                  {inputNumber ? '---' : currentChannel?.name}
                </h2>
              </div>
              <div className="flex items-center space-x-3 mt-2 text-gray-300">
                <span className="px-2 py-1 bg-white/10 rounded text-sm font-medium uppercase tracking-wider">
                  {inputNumber ? '---' : (currentChannel?.group || 'Live TV')}
                </span>
                <span className="flex items-center text-sm">
                  <span className="w-2 h-2 rounded-full bg-red-500 mr-2 animate-pulse"></span>
                  LIVE
                </span>
              </div>
            </div>
          </div>
          
          {/* Right side info */}
          <div className="text-right text-white/70 flex flex-col items-end">
            <div className="text-2xl font-light mb-1">
              {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <Info className="w-4 h-4" />
              <span>Press +/- to change</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile/Touch Controls (hidden on desktop if using keyboard, but useful for touch) */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col space-y-4 opacity-0 hover:opacity-100 transition-opacity duration-300">
        <button 
          onClick={() => changeChannel('up')}
          className="w-12 h-12 bg-black/50 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/20 hover:bg-white/20 active:scale-95 transition-all"
        >
          <span className="text-2xl font-bold">+</span>
        </button>
        <button 
          onClick={() => changeChannel('down')}
          className="w-12 h-12 bg-black/50 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/20 hover:bg-white/20 active:scale-95 transition-all"
        >
          <span className="text-2xl font-bold">-</span>
        </button>
      </div>
    </div>
  );
}
