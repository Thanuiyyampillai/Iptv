/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import Hls from 'hls.js';
import { Tv, List, Hash, AlertCircle, Play } from 'lucide-react';
import { cn } from './lib/utils';
import { motion, AnimatePresence } from 'motion/react';

const channels = [
  { id: 1, name: "3 Star TV", url: "https://stream.onecloudlive.in/threestartv/threestarhd/index.m3u8", working: true },
  { id: 2, name: "7 Green 4K", url: "https://account33.livebox.co.in/7GREEN4Khls/live.m3u8", working: true },
  { id: 3, name: "7 Star Premium", url: "http://premium.7starcloud.com:1935/live/7star/playlist.m3u8", working: true },
  { id: 4, name: "7 Star Premium 2", url: "http://media.7starcloud.com:1935/live/7star/playlist.m3u8", working: true },
  { id: 5, name: "7Star HD", url: "http://hdserver.7starcloud.com:1935/live/7star2/playlist.m3u8", working: true },
  { id: 6, name: "7Star Music", url: "http://premium.7starcloud.com:1935/live/7starmusic/playlist.m3u8", working: true },
  { id: 7, name: "7Star Television", url: "https://annainew.livebox.co.in/7startvhls/livestream.m3u8", working: true },
  { id: 8, name: "A1 TV", url: "https://app.ashokadigital.net/app/7fff5003/index.m3u8", working: true },
  { id: 9, name: "A1 TV Ariyalur", url: "https://app.ashokadigital.net/app/0fca457c/index.m3u8", working: true },
  { id: 10, name: "Aadhavan Tamil TV", url: "http://aadhavantamiltv.phoenixcreations.online/aadhavantamiltv/aadhavantamiltv/index.m3u8", working: true },
  { id: 11, name: "Aadhavan Tamil TV", url: "http://aadhavantamiltv.phoenixcreations.online/aadhavantamiltv/aadhavantamiltv/index.m3u8", working: true },
  { id: 12, name: "Aadhavan TV", url: "https://view.apserver.in/tmp_hls3/aadhavantv/index.m3u8", working: true },
  { id: 13, name: "Aalayamagimai TV", url: "https://stream.ashokadigital.net/aalayamagimaitv/aalayamagimaitv/index.m3u8", working: true },
  { id: 14, name: "Aaron TV", url: "http://stream.onecloudlive.in/sachintv/aarontvhd/index.m3u8", working: true },
  { id: 15, name: "Aaron TV HD", url: "http://stream.onecloudlive.in/sachintv/aarontvhd/index.m3u8", working: true },
  { id: 16, name: "Aaryaa TV", url: "https://stream.ottlive.co.in/aryatvtamil/index.m3u8", working: true },
  { id: 17, name: "Aasai TV", url: "https://notvstream.in/aasaitv/aasaitv/index.m3u8", working: true },
  { id: 18, name: "Abi TV", url: "https://mumt02.tangotv.in/ABITV/index.m3u8", working: true },
  { id: 19, name: "Abinaya TV", url: "https://app.xstream.onecloudlive.in/abinayatv/abinayatv/index.m3u8", working: true },
  { id: 20, name: "Abinaya TV", url: "http://xstream.onecloudlive.in:8080/abinayatv/abinayatv/index.m3u8", working: true },
  { id: 21, name: "ACN TV", url: "https://web.applelive.in/stream/acntv/index.m3u8", working: true },
  { id: 22, name: "ACP Classic", url: "http://103.87.105.51:8080/acpclassic/acpclassic.m3u8?psk=123456", working: true },
  { id: 23, name: "ACP Classic", url: "http://103.87.105.51:8080/acpclassic/acpclassic.m3u8?psk=123456", working: true },
  { id: 24, name: "ACP TV", url: "http://103.87.105.51:8080/acphd/acphd.m3u8?psk=123456", working: true },
  { id: 25, name: "ACP TV", url: "http://103.87.105.51:8080/acphd/acphd.m3u8?psk=123456", working: true },
  { id: 26, name: "Adhisayam TV", url: "https://livetv.adhisayamtv.org/adhisayamtv/83a062a18a761b948a73ad2ba7747a8f.sdp/playlist.m3u8", working: true },
  { id: 27, name: "Adhiyamam TV", url: "https://hd.singamcloud.in/adhiyamamtv/adhiyamamtv/index.m3u8", working: true },
  { id: 28, name: "Aha TV", url: "https://rtmp.bmlive.net/bms/ahatv/index.m3u8", working: true },
  { id: 29, name: "Ajay TV", url: "http://ajaytv.sscloud7.in/live/ajaytv/index.m3u8", working: true },
  { id: 30, name: "AK TV", url: "https://stream.rojatv.cloud/AKTV/onecloud/index.m3u8", working: true },
  { id: 31, name: "AK TV HD 2", url: "https://stream.onecloudlive.in/aktvhd/aktv/index.m3u8", working: true },
  { id: 32, name: "Akilam TV (2 min catchup)", url: "https://stream.rojatv.cloud/AKILAMTV/onecloud/index.m3u8", working: true },
  { id: 33, name: "Akilam TV HD", url: "https://stream.onecloudlive.in/akilamtv/akilamtvhd/index.m3u8", working: true },
  { id: 34, name: "ALM Thendral TV", url: "http://almthendraltv.phoenixcreations.online/almthendraltv/almthendraltv/playlist.m3u8", working: true },
  { id: 35, name: "Amma TV", url: "https://annainew.livebox.co.in/ammatvhls/live.m3u8", working: true },
  { id: 36, name: "Amma TV Nagercoil", url: "https://web.applelive.in/stream/ammatv/index.m3u8", working: true },
  { id: 37, name: "Amma Vision", url: "https://view.rcserver.in/tmp_hls19/ammavision/index.m3u8", working: true },
  { id: 38, name: "Amman TV", url: "https://app.ashokadigital.net/app/78b1bc36/index.m3u8", working: true },
  { id: 39, name: "Analai Express", url: "http://198.144.149.206:8080/ANALAI_MOVIE/index.m3u8?token=GTR", working: true },
  { id: 40, name: "Analai Express Cinema", url: "http://198.144.149.206:8080/MONTAMIL_CINEMA/index.m3u8?token=GTR", working: true },
  { id: 41, name: "Analai Movie", url: "http://198.144.149.206:8080/ANALAI_MOVIE/index.m3u8?token=GTR", working: true },
  { id: 42, name: "Anandam TV", url: "https://notvstream.in/anandamtv/anandamtv/index.m3u8", working: true },
  { id: 43, name: "Anbu TV HD", url: "https://ipcloud.live/anbutv/anbutvhd/index.m3u8", working: true },
  { id: 44, name: "Anisa TV", url: "https://web.applelive.in/anisatv/anisatv/index.m3u8", working: true },
  { id: 45, name: "Anjai TV", url: "https://web.applelive.in/stream/anjaitv/index.m3u8", working: true },
  { id: 46, name: "Annai Live", url: "https://annainew.livebox.co.in/annailivehls/live.m3u8", working: true },
  { id: 47, name: "Annai Tamil", url: "https://annainew.livebox.co.in/annaitamilhls/live.m3u8", working: true },
  { id: 48, name: "Annai TV Thoothukudi", url: "http://annaitv.phoenixcreations.online/annai/annaitv/index.m3u8", working: true },
  { id: 49, name: "Annai TV Thoothukudi", url: "http://annaitv.phoenixcreations.online/annai/annaitv/index.m3u8", working: true },
  { id: 50, name: "Apple TV", url: "https://play.applelive.in/appletv/appletv.m3u8", working: true },
  { id: 51, name: "Apple TV 2", url: "http://applelive.in/appletv/appletv.m3u8", working: true },
  { id: 52, name: "Apple TV KLM", url: "https://play.applelive.in/appletv/appletvklm.m3u8", working: true },
  { id: 53, name: "Apple TV Stream", url: "https://web.applelive.in/stream/appletv/index.m3u8", working: true },
  { id: 54, name: "Appu TV", url: "http://198.144.149.206:8080/NOTV/IWORLDHD/index.m3u8?token=GTR", working: true },
  { id: 55, name: "APS Gold", url: "https://apsgold-a1.tamilstream.in/apsgold/apsgold/index.m3u8", working: true },
  { id: 56, name: "APS TV", url: "http://apstv.phoenixcreations.online/apstv/apstv/index.m3u8", working: true },
  { id: 57, name: "APS TV", url: "https://apstv-a1.tamilstream.in/apstv/apstv/index.m3u8", working: true },
  { id: 58, name: "APS TV 2", url: "http://apstv.phoenixcreations.online/apstv/apstv/playlist.m3u8", working: true },
  { id: 59, name: "APS TV 2", url: "https://apstv-a1.tamilstream.in/apstv/apstv/index.m3u8", working: true },
  { id: 60, name: "Aramm TV", url: "https://singamcloud.in/arammtv/arammtv/index.m3u8", working: true },
  { id: 61, name: "Arighni TV", url: "https://dmtv.iptv.pics/live/dmtv/index.m3u8", working: true },
  { id: 62, name: "ARK", url: "https://ark.inet.moe/ark/index.m3u8", working: true },
  { id: 63, name: "Arputhar Yesu TV", url: "https://arputharyesutv.arputharyesutv.com/live/md/index.m3u8", working: true },
  { id: 64, name: "Arram TV", url: "http://hdstreambox.in:1935/Arramtv/livetv/playlist.m3u8", working: true },
  { id: 65, name: "Arram TV Komarapalayam", url: "https://stream.rojatv.cloud/Arramtv/komarapalayam/index.m3u8", working: true },
  { id: 66, name: "Arul TV", url: "http://arulstream.in:1935/ArulTv/live/playlist.m3u8", working: true },
  { id: 67, name: "Arul TV", url: "http://arulstream.in:1935/ArulTv/live/playlist.m3u8", working: true },
  { id: 68, name: "Arunai TV", url: "https://notvstream.in/arunaitv/arunaitv/index.m3u8", working: true },
  { id: 69, name: "Ashoka TV", url: "http://stream.ashokadigital.net/ashokaslm/live/index.m3u8", working: true },
  { id: 70, name: "Ashoka TV 1", url: "https://app.ashokadigital.net/app/12f5e922/index.m3u8", working: true },
  { id: 71, name: "Ashoka TV 2", url: "https://app.ashokadigital.net/app/a3e0b02f/index.m3u8", working: true },
  { id: 72, name: "Ashoka TV 20", url: "https://app.ashokadigital.net/app/8fe44fd0/index.m3u8", working: true },
  { id: 73, name: "Ashoka TV 7", url: "https://app.ashokadigital.net/app/ed8bd4a7/index.m3u8", working: true },
  { id: 74, name: "Ashoka TV 8", url: "https://app.ashokadigital.net/app/9346e98d/index.m3u8", working: true },
  { id: 75, name: "Athi Thoothar TV", url: "https://server.sscloud7.in/live/athithoothartv/index.m3u8", working: true },
  { id: 76, name: "ATN", url: "https://play.applelive.in/atn/atn.m3u8", working: true },
  { id: 77, name: "ATN", url: "https://stream.onecloudlive.in/atntv/atnhd/index.m3u8", working: true },
  { id: 78, name: "ATN [RojaTV]", url: "https://stream.rojatv.cloud/ATNHD/onecloud/index.m3u8", working: true },
  { id: 79, name: "Ayya TV 2", url: "https://live1.sscloud7.in/live/ayyatv/playlist.m3u8", working: true },
  { id: 80, name: "Ayya TV 3", url: "https://play.applelive.in/ayyatv/ayyatv.m3u8", working: true },
  { id: 81, name: "Ayya Vaikundar TV", url: "https://stream.rojatv.cloud/AYYAVAIKUNDARTV/onecloud/index.m3u8", working: true },
  { id: 82, name: "Azhagi TV", url: "https://view.rcserver.in/tmp_hls17/azhagitv/index.m3u8", working: true },
  { id: 83, name: "Bass TV", url: "https://app.xstream.onecloudlive.in/bass/basstv/index.m3u8", working: true },
  { id: 84, name: "Bass TV", url: "http://xstream.onecloudlive.in:8080/bass/basstv/index.m3u8", working: true },
  { id: 85, name: "Bhagyam TV", url: "https://www.offer360.in/bhagyamtv/bhagyam/index.m3u8", working: true },
  { id: 86, name: "Bhairava HD", url: "https://stream.onecloudlive.in/bhairavatv/bhairavahd/index.m3u8", working: true },
  { id: 87, name: "Bhakthi TV", url: "https://live.sscloud7.in/live/bhakthitv/index.m3u8", working: true },
  { id: 88, name: "Bharathi TV", url: "https://server.sscloud7.in/live/bharathitv/index.m3u8", working: true },
  { id: 89, name: "BM TV", url: "https://rtmp.bmlive.net/bms/bmtv/stream.m3u8", working: true },
  { id: 90, name: "Boys TV", url: "https://rtmp.applelive.in/boystv/boystv/index.m3u8", working: true },
  { id: 91, name: "Bright Simrose TV", url: "https://notvstream.in/brightsimrosetv/brightsimrosetv/index.m3u8", working: true },
  { id: 92, name: "Britain Tamil Bhakthi", url: "http://btc.inet.moe/live/btctv/index.m3u8", working: true },
  { id: 93, name: "Britain Tamil Bhakthi", url: "http://btc.inet.moe/live/btctv/index.m3u8", working: true },
  { id: 94, name: "BSC TV", url: "https://live.singamcloud.in/bsctv/bsctv/index.m3u8", working: true },
  { id: 95, name: "Citi TV HD", url: "https://stream.ashokadigital.net/cititv/cititvhd/index.m3u8", working: true },
  { id: 96, name: "City TV 2", url: "https://stream.onecloudlive.in/citytv/citytv/index.m3u8", working: true },
  { id: 97, name: "Crayonz TV [7Star]", url: "http://v.7starcloud.com:1935/live/crayonztv/playlist.m3u8", working: true },
  { id: 98, name: "Cross Src", url: "https://ytv.iptv.pics/hls/cross_src/index.m3u8", working: true },
  { id: 99, name: "CRS TV", url: "https://play.applelive.in/crstv/crstv.m3u8", working: true },
  { id: 100, name: "CSK TV", url: "https://stream.ashokadigital.net/csktv/csktv/index.m3u8", working: true },
  { id: 101, name: "CTN Arasu", url: "https://ipcloud.live/ctn/arasu/index.m3u8", working: true },
  { id: 102, name: "CTN Channel", url: "https://stream.ashokadigital.net/ctntv/ctntv/index.m3u8", working: true },
  { id: 103, name: "CTN Magalir", url: "https://ipcloud.live/ctn/magalir/index.m3u8", working: true },
  { id: 104, name: "CTN TN", url: "https://rtmp.bmlive.net/ctn/ctntn/stream.m3u8", working: true },
  { id: 105, name: "CTV", url: "http://ctv.phoenixcreations.online/ctv/ctv/playlist.m3u8", working: true },
  { id: 106, name: "Dark TV", url: "https://play.applelive.in/darktv/darktv.m3u8", working: true },
  { id: 107, name: "Dark TV 2", url: "http://applelive.in/darktv/darktv.m3u8", working: true },
  { id: 108, name: "DBhakhi", url: "https://stream.d6-pro.com/Dbhakhi/live/index.m3u8", working: true },
  { id: 109, name: "DD TV", url: "https://stream.sscloud7.in/live/ddtv/index.m3u8", working: true },
  { id: 110, name: "Deavathai TV", url: "https://ipcloud.live/devadhaitv/devadhaitv/index.m3u8", working: true },
  { id: 111, name: "Deepam TV", url: "http://deepam.7starcloud.com:1935/live/deepamtv/live.m3u8", working: true },
  { id: 112, name: "Deiva Oli", url: "https://stream.sscloud7.in/live/deivaoli/index.m3u8", working: true },
  { id: 113, name: "Deiveega Oli TV", url: "https://stream.onecloudlive.in/karthick/deivegaolitv/index.m3u8", working: true },
  { id: 114, name: "Delta TV", url: "https://live.onecloudlive.in/delta/namtv/index.m3u8", working: true },
  { id: 115, name: "Deva TV", url: "http://devatv.applelive.in/devatv/devatv.m3u8", working: true },
  { id: 116, name: "Deva TV", url: "http://devatv.sscloud7.in/live/devatv/index.m3u8", working: true },
  { id: 117, name: "Deva TV 2", url: "https://play.applelive.in/devatv/devatv.m3u8", working: true },
  { id: 118, name: "Devi TV", url: "http://server.mindspell.in/live/devitv/index.m3u8", working: true },
  { id: 119, name: "Devi TV 3", url: "https://server.sscloud7.in/live/devitv/index.m3u8", working: true },
  { id: 120, name: "Dharshan TV", url: "https://galaxyott.live/hls/dharshantv.m3u8", working: true },
  { id: 121, name: "Dharumai Adeenam TV", url: "https://stream.onecloudlive.in/taitaltv/livetv/index.m3u8", working: true },
  { id: 122, name: "Dheiveegam TV", url: "https://stream.singamcloud.in/Dheiveegamtv/Dheiveegamtv/index.m3u8", working: true },
  { id: 123, name: "Digital TV", url: "https://play.applelive.in/digitaltv/digitaltv.m3u8", working: true },
  { id: 124, name: "Digital TV 2", url: "http://applelive.in/digitaltv/digitaltv.m3u8", working: true },
  { id: 125, name: "Divine TV", url: "https://ipcloud.live/novamani/divinetv/index.m3u8", working: true },
  { id: 126, name: "Dolphin TV", url: "https://play.applelive.in/dolphintv/dolphintv.m3u8", working: true },
  { id: 127, name: "DTV", url: "https://stream.d6-pro.com/Dtv/live/index.m3u8", working: true },
  { id: 128, name: "Durai TV Classic", url: "https://stream.onecloudlive.in/duraitv/classic/index.m3u8", working: true },
  { id: 129, name: "Eagle Media TV", url: "https://ipcloud.live/eaglemedia/eagletv/index.m3u8", working: true },
  { id: 130, name: "Eagle TV", url: "https://rtmp.bmlive.net/bms/eagletv/stream.m3u8", working: true },
  { id: 131, name: "Eagle TV Nagercoil", url: "https://play.applelive.in/eagletv/eagletv.m3u8", working: true },
  { id: 132, name: "Eesan TV", url: "http://live.singamcloud.in/eesantv/eesantv/index.m3u8", working: true },
  { id: 133, name: "Eesan TV 2", url: "https://live.singamcloud.in/eesantv/eesantv/index.m3u8", working: true },
  { id: 134, name: "EET TV", url: "https://live.streamjo.com/eetlive/eettv.m3u8", working: true },
  { id: 135, name: "EET TV", url: "https://eu.streamjo.com/eetlive/eettv.m3u8", working: true },
  { id: 136, name: "Enthiran TV", url: "https://play.applelive.in/hls/enthirantv.m3u8", working: true },
  { id: 137, name: "Ezhil HD", url: "https://stream.onecloudlive.in/ezhiltv/ezhilhd/index.m3u8", working: true },
  { id: 138, name: "Ezhil TV", url: "http://198.144.149.206:8080/NOTV/EZHILTV/index.m3u8?token=GTR", working: true },
  { id: 139, name: "Ezhil TV", url: "http://198.144.149.206:8080/NOTV/EZHILTV/index.m3u8?token=GTR", working: true },
  { id: 140, name: "Fort Channel", url: "https://stream.onecloudlive.in/forttv/fortchannel/index.m3u8", working: true },
  { id: 141, name: "G Max", url: "https://play.applelive.in/gcv/gcv.m3u8", working: true },
  { id: 142, name: "G TV Kumbakonam", url: "https://live.singamcloud.in/gtv/gtv/index.m3u8", working: true },
  { id: 143, name: "Garudan TV", url: "http://garudatv.applelive.in/hls/garudantv.m3u8", working: true },
  { id: 144, name: "Garudan TV 2", url: "https://play.applelive.in/hls/garudantv.m3u8", working: true },
  { id: 145, name: "GCV", url: "http://applelive.in/gcv/gcv.m3u8", working: true },
  { id: 146, name: "Gem TV", url: "https://gemtv.circle7stream.com/gem/fcce47a8559e30755582c396ce7fce9e.sdp/playlist.m3u8", working: true },
  { id: 147, name: "Go Revival TV", url: "https://ktismaservers.in:3870/live/gorevivaltvlive.m3u8", working: true },
  { id: 148, name: "Good News Time", url: "https://5dd3981940faa.streamlock.net/goodnewstime/goodnewstime/playlist.m3u8", working: true },
  { id: 149, name: "Gospel TV", url: "https://play.applelive.in/gospeltv/gospeltv.m3u8", working: true },
  { id: 150, name: "GSJK TV", url: "http://brightmeltech.in/gsjktv/gsjktv.m3u8", working: true },
  { id: 151, name: "GSJK TV", url: "http://live.brightmeltech.in/gsjktv/gsjktv.m3u8", working: true },
  { id: 152, name: "GTA Tamil", url: "http://144.217.77.42:8888/gta_tamil/index.m3u8", working: true },
  { id: 153, name: "GTA Tamil", url: "http://144.217.77.42:8888/gta_tamil/index.m3u8", working: true },
  { id: 154, name: "GTV", url: "http://live.singamcloud.in/gtv/gtv/index.m3u8", working: true },
  { id: 155, name: "GTV Max", url: "http://applelive.in/gtvmax/gtvmax.m3u8", working: true },
  { id: 156, name: "GV Kumari TV", url: "https://rtmp.applelive.in/gvkumaritv/gvkumaritv/index.m3u8", working: true },
  { id: 157, name: "Hansitha TV", url: "https://hd.rojatv.cloud/hansitha/tv/index.m3u8", working: true },
  { id: 158, name: "Harin TV HD", url: "https://ipcloud.live/harintv/harintvhd/index.m3u8", working: true },
  { id: 159, name: "Hello Tamil TV", url: "https://view.rcserver.in/tmp_hls26/hellotamiltv/index.m3u8", working: true },
  { id: 160, name: "Hitech TV", url: "https://notvstream.in/hitechtv/hitechtv/index.m3u8", working: true },
  { id: 161, name: "Hybrid Stream", url: "https://ktismaservers.in:3220/hybrid/play.m3u8", working: true },
  { id: 162, name: "Image Sequence", url: "https://account18.livebox.co.in/IMAGESEQUENCEhls/live.m3u8", working: true },
  { id: 163, name: "Irattai Paathai TV", url: "https://account31.livebox.co.in/IRATTAIPAATHAITVhls/live.m3u8", working: true },
  { id: 164, name: "Isai Saral", url: "http://srnet.bmlive.net:1935/isaisaral/mystream/playlist.m3u8", working: true },
  { id: 165, name: "Isai Saral", url: "http://srnet.bmlive.net:1935/isaisaral/mystream/playlist.m3u8", working: true },
  { id: 166, name: "Islamic Channel", url: "https://play.applelive.in/islamicchannel/islamicchannel.m3u8", working: true },
  { id: 167, name: "IWorld HD", url: "http://198.144.149.206:8080/NOTV/IWORLDHD/index.m3u8?token=GTR", working: true },
  { id: 168, name: "J Jeyam", url: "https://stream.singamcloud.in/jjeyam/jjeyam/index.m3u8", working: true },
  { id: 169, name: "Jai TV", url: "https://play.applelive.in/jaitv/jaitv.m3u8", working: true },
  { id: 170, name: "Jawahar Channel", url: "https://app.ashokadigital.net/app/6a01fb97/index.m3u8", working: true },
  { id: 171, name: "Jawahar Channel HD", url: "http://jawahar.7starcloud.com:1935/jawahartv/streamingbox2/playlist.m3u8", working: true },
  { id: 172, name: "Jawahar TV", url: "http://jawahar.7starcloud.com:1935/live/app/playlist.m3u8", working: true },
  { id: 173, name: "Jawahar TV 2", url: "http://jawahar.7starcloud.com:1935/jawahartv/streamingbox2/playlist.m3u8", working: true },
  { id: 174, name: "Jay TV HD", url: "https://stream.onecloudlive.in/jaytv/jaytvhd/index.m3u8", working: true },
  { id: 175, name: "Jayaam TV", url: "http://jayaam.7starcloud.com:1935/jayaamtv/jayaamtv/playlist.m3u8", working: true },
  { id: 176, name: "Jayaam TV", url: "http://hdserver.7starcloud.com:1935/jayaamtv/jayaamtv/playlist.m3u8", working: true },
  { id: 177, name: "Jayaam TV", url: "https://app.ashokadigital.net/app/67a779e9/index.m3u8", working: true },
  { id: 178, name: "Jayam TV", url: "https://view.rcserver.in/tmp_hls20/index.m3u8", working: true },
  { id: 179, name: "Jayam TV HD", url: "https://ipcloud.live/jayamtv/jayamtvhd/index.m3u8", working: true },
  { id: 180, name: "Jayam TV Namakkal", url: "https://rtmp.bmlive.net/bms/jayamtv/stream.m3u8", working: true },
  { id: 181, name: "Jayam TV Sivakasi", url: "https://stream.rojatv.cloud/jayam4k/index.m3u8", working: true },
  { id: 182, name: "Jayam TV Sivakasi [Phoenix]", url: "https://jayamtv-ott.tamilstream.in/jayamtv/sivakasi/playlist.m3u8", working: true },
  { id: 183, name: "Jayam TV Tenkasi", url: "https://ipcloud.live/jayamtv/jayamtvhd/index.m3u8?token=jayamtv", working: true },
  { id: 184, name: "Jayam TV Trichy", url: "https://live.onecloudlive.in/jmhd/jmtv/index.m3u8", working: true },
  { id: 185, name: "JC TV", url: "https://play.applelive.in/jctv/jctv.m3u8", working: true },
  { id: 186, name: "JC TV 2", url: "http://applelive.in/jctv/jctv.m3u8", working: true },
  { id: 187, name: "JC TV Live 2", url: "https://jctvapp.lanevservices.in/jcfcapp/jctvlive/playlist.m3u8", working: true },
  { id: 188, name: "JC TV Madurai", url: "https://ktismaservers.in:3545/live/jctvlive.m3u8", working: true },
  { id: 189, name: "JCV Musix", url: "https://play.applelive.in/jcvtv/jcvmusix.m3u8", working: true },
  { id: 190, name: "JCV TV", url: "https://play.applelive.in/jcvtv/jcvtv.m3u8", working: true },
  { id: 191, name: "Jeeva Oli TV", url: "http://jaeppiyar.livebox.co.in/jeevaolitvhls/live.m3u8", working: true },
  { id: 192, name: "Jeeva Oli TV 2", url: "https://jaeppiyar.livebox.co.in/jeevaolitvhls/live.m3u8", working: true },
  { id: 193, name: "Jeevan TV", url: "https://stream.singamcloud.in/Jeevantv/Jeevantv/index.m3u8", working: true },
  { id: 194, name: "Jenifer TV", url: "https://live1.sscloud7.in/live/jenifertv/index.m3u8", working: true },
  { id: 195, name: "Jesus TV", url: "https://play.applelive.in/jesustv/jesustv.m3u8", working: true },
  { id: 196, name: "Jeya Subbu TV", url: "https://view.rcserver.in/tmp_hls6/jeyasubbutv/index.m3u8", working: true },
  { id: 197, name: "Jeyam Plus", url: "https://ipcloud.live/mmtv/jeyamplus/index.m3u8", working: true },
  { id: 198, name: "Jeyam Plus 2", url: "https://stream.singamcloud.in/jeyamplus/jeyamplus/index.m3u8", working: true },
  { id: 199, name: "Jeyam Television", url: "https://jeyamtv.livebox.co.in/JeyamTelevisionhls/JeyamTelevision.m3u8", working: true },
  { id: 200, name: "Jeyam TV 2", url: "https://live.sscloud7.in/live/jeyamtv/index.m3u8", working: true },
  { id: 201, name: "Jeyan TV", url: "https://stream.onecloudlive.in/jeyantv/jeyantv/index.m3u8", working: true },
  { id: 202, name: "Jeyson TV", url: "https://play.applelive.in/jeysontv/jeysontv.m3u8", working: true },
  { id: 203, name: "Jeyson TV 2", url: "http://jeyson.applelive.in/jeysontv/jeysontv.m3u8", working: true },
  { id: 204, name: "Jith TV", url: "https://sscloud7.com/live/jithtv/index.m3u8", working: true },
  { id: 205, name: "JJ Max", url: "https://play.applelive.in/jjmax/jjmax.m3u8", working: true },
  { id: 206, name: "JJ Max 2", url: "http://jeyson.applelive.in/jjmax/jjmax.m3u8", working: true },
  { id: 207, name: "Jos TV", url: "http://jostv.phoenixcreations.online/jostv/jostv/index.m3u8", working: true },
  { id: 208, name: "Jos TV", url: "http://jostv.phoenixcreations.online/jostv/jostv/index.m3u8", working: true },
  { id: 209, name: "Jose TV", url: "http://josetv.phoenixcreations.online/josetv/josetv/index.m3u8", working: true },
  { id: 210, name: "Jose TV", url: "http://josetv.phoenixcreations.online/josetv/josetv/index.m3u8", working: true },
  { id: 211, name: "Jose TV 2", url: "http://josetv.phoenixcreations.online/josetv/josetv/playlist.m3u8", working: true },
  { id: 212, name: "Joshua Praise TV", url: "http://joshuatv-live.phoenixcreations.online/joshuatv/live/playlist.m3u8", working: true },
  { id: 213, name: "Joshua TV", url: "http://joshuatv.phoenixcreations.online/joshuatv/joshuatv/index.m3u8", working: true },
  { id: 214, name: "Joshua TV", url: "http://joshuatv.phoenixcreations.online/joshuatv/joshuatv/index.m3u8", working: true },
  { id: 215, name: "Jothi Bala TV", url: "http://jothibalatv.phoenixcreations.online/jothibalatv/jothibalatv/index.m3u8", working: true },
  { id: 216, name: "Jothibala TV", url: "http://jothibalatv.phoenixcreations.online/jothibalatv/jothibalatv/index.m3u8", working: true },
  { id: 217, name: "Jowh TV", url: "http://jowhtv.phoenixcreations.online/jowhtv/jowh/index.m3u8", working: true },
  { id: 218, name: "Jowh TV", url: "http://jowhtv.phoenixcreations.online/jowhtv/jowh/index.m3u8", working: true },
  { id: 219, name: "Joy Good News TV", url: "https://play.applelive.in/joygoodnewstv/joygoodnewstv.m3u8", working: true },
  { id: 220, name: "Joy Goodnews TV [IndiaMatrix]", url: "http://indiamatrix.in/goodnewstv/goodnewstv.m3u8", working: true },
  { id: 221, name: "Joy TV", url: "https://joy.inet.moe/live/joytv/index.m3u8", working: true },
  { id: 222, name: "Joy TV HD", url: "https://ktismaservers.in:3412/live/joytvlive.m3u8", working: true },
  { id: 223, name: "JP TV HD", url: "https://cloudstream4k.com/jptvhd/bsk/playlist.m3u8", working: true },
  { id: 224, name: "JRP HD", url: "https://ipcloud.live/jrptv/jrphd/index.m3u8", working: true },
  { id: 225, name: "JRP HD", url: "http://ipcloud.live:8080/jrptv/jrphd/index.m3u8", working: true },
  { id: 226, name: "Kaalai TV", url: "https://view.rcserver.in/tmp_hls23/kaalaitv/index.m3u8", working: true },
  { id: 227, name: "Kaka TV", url: "http://kakatv.phoenixcreations.online/kakatv/kaka/index.m3u8", working: true },
  { id: 228, name: "Kaka TV", url: "http://kakatv.phoenixcreations.online/kakatv/kaka/index.m3u8", working: true },
  { id: 229, name: "Kanchi Media", url: "http://198.144.149.206:8080/NOTV/KANCHIMEDIA/index.m3u8?token=GTR", working: true },
  { id: 230, name: "Kanchi Media", url: "http://198.144.149.206:8080/NOTV/KANCHIMEDIA/index.m3u8?token=GTR", working: true },
  { id: 231, name: "Kanna TV", url: "http://kannatv.phoenixcreations.online/kannatv/kanna/index.m3u8", working: true },
  { id: 232, name: "Kanna TV", url: "http://kannatv.phoenixcreations.online/kannatv/kanna/index.m3u8", working: true },
  { id: 233, name: "Karnan GTV", url: "https://stream.onecloudlive.in/karnan/gtv/index.m3u8", working: true },
  { id: 234, name: "Karnan National TV", url: "https://stream.onecloudlive.in/karnan/Nationaltv/index.m3u8", working: true },
  { id: 235, name: "Karnan Vanavil TV", url: "https://stream.onecloudlive.in/karnan/vanaviltv/index.m3u8", working: true },
  { id: 236, name: "Kavin TV", url: "http://198.144.149.206:8080/NOTV/KAVINTV/index.m3u8?token=GTR", working: true },
  { id: 237, name: "Kavin TV", url: "http://198.144.149.206:8080/NOTV/KAVINTV/index.m3u8?token=GTR", working: true },
  { id: 238, name: "Kavin TV 2", url: "http://198.144.149.206:8080/NOTV/KAVINTV/tracks-v1a1/mono.m3u8?token=GTR", working: true },
  { id: 239, name: "Kayal TV", url: "https://kayal.inet.moe/kayal/kayaltv/index.m3u8", working: true },
  { id: 240, name: "KC Music", url: "https://rtmp.bmlive.net/bms/kcmusic/index.m3u8", working: true },
  { id: 241, name: "KC TV", url: "https://rtmp.bmlive.net/bms/kctv/stream.m3u8", working: true },
  { id: 242, name: "KCN TV", url: "https://view.rcserver.in/tmp_hls12/kcntv/index.m3u8", working: true },
  { id: 243, name: "Khila TV", url: "http://khilatv.phoenixcreations.online/khilatv/khilatv/playlist.m3u8", working: true },
  { id: 244, name: "King 24x7", url: "https://notvstream.in/kingtv/kingtv/index.m3u8", working: true },
  { id: 245, name: "King of Glory TV", url: "https://ipcloud.live/novamani/kingofglorytv/index.m3u8", working: true },
  { id: 246, name: "King TV", url: "https://rtmp.bmlive.net/kingtv/kingtv/stream.m3u8", working: true },
  { id: 247, name: "King TV Ranipet", url: "https://ipcloud.live/kingtv/kingtv/index.m3u8", working: true },
  { id: 248, name: "Kirubai TV", url: "https://server1.thewebworld.in:3208/hybrid/play.m3u8", working: true },
  { id: 249, name: "KM Music", url: "https://stream.ashokadigital.net/kmmusic/kmmusic/index.m3u8", working: true },
  { id: 250, name: "KRN TV HD", url: "https://stream.onecloudlive.in/krntv/krntvhd/index.m3u8", working: true },
  { id: 251, name: "KRN TV HD 2", url: "https://stream.rojatv.cloud/KRNTVHD/onecloud/index.m3u8", working: true },
  { id: 252, name: "KSR TV", url: "http://ksrtv.stream.onecloudlive.in:8080/ksrtv/ksrtvhd/index.m3u8", working: true },
  { id: 253, name: "KSR TV HD", url: "http://ksrtv.stream.onecloudlive.in:8080/ksrtv/ksrtvhd/index.m3u8", working: true },
  { id: 254, name: "Kumaran TV", url: "https://stream.rojatv.cloud/kumarantv/gobi/index.m3u8", working: true },
  { id: 255, name: "Kumari TV", url: "https://play.applelive.in/kumaritv/gvkumaritv.m3u8", working: true },
  { id: 256, name: "Leo TV [IPLive]", url: "https://stream.iplive.xyz/hls/leotv/index.m3u8", working: true },
  { id: 257, name: "Life TV", url: "http://lifetv.livebox.co.in/lifetvhls/lifetv.m3u8", working: true },
  { id: 258, name: "Life TV 2", url: "https://lifetv.livebox.co.in/lifetvhls/lifetv.m3u8", working: true },
  { id: 259, name: "Life TV Tamil", url: "http://lifetv.livebox.co.in/lifetvtamilhls/live.m3u8", working: true },
  { id: 260, name: "Lion TV", url: "https://stream.iplive.xyz/smmedia/liontv/index.m3u8", working: true },
  { id: 261, name: "Lotus TV", url: "http://lotustv.phoenixcreations.online/lotustv/lotustv/index.m3u8", working: true },
  { id: 262, name: "Lotus TV", url: "http://lotustv.phoenixcreations.online/lotustv/lotustv/index.m3u8", working: true },
  { id: 263, name: "Lucky TV", url: "https://stream.rojatv.cloud/LUCKYTV/onecloud/index.m3u8", working: true },
  { id: 264, name: "Lucky TV", url: "http://luckytv.stream.onecloudlive.in/luckytv/luckytvhd/index.m3u8", working: true },
  { id: 265, name: "Lucky TV", url: "http://luckytv.stream.onecloudlive.in/luckytv/luckytvhd/index.m3u8", working: true },
  { id: 266, name: "Maa TV", url: "http://maatv.phoenixcreations.online/maatv/maatv/index.m3u8", working: true },
  { id: 267, name: "Maa TV 2", url: "http://live.singamcloud.in/maatv/maatv/index.m3u8", working: true },
  { id: 268, name: "Maa TV 3", url: "https://live.singamcloud.in/maatv/maatv/index.m3u8", working: true },
  { id: 269, name: "Madha TV", url: "http://103.109.45.5:1935/madhatv/madhatv.stream_HDp/chunklist_w67072347.m3u8", working: true },
  { id: 270, name: "Madhan TV", url: "http://madhantv.phoenixcreations.online/madhantv/madhantv/index.m3u8", working: true },
  { id: 271, name: "Madura TV", url: "https://stream.onecloudlive.in/mm/maduratv/index.m3u8", working: true },
  { id: 272, name: "Magizh TV", url: "http://magizhtv.phoenixcreations.online/magizhtv/magizhtv/index.m3u8", working: true },
  { id: 273, name: "Magizh TV", url: "http://magizhtv.phoenixcreations.online/magizhtv/magizhtv/index.m3u8", working: true },
  { id: 274, name: "Mahimai TV Live", url: "https://ktismaservers.in:3161/live/mahimaitvlive.m3u8", working: true },
  { id: 275, name: "Maisha TV", url: "https://stream.sscloud7.in/live/maishatv/index.m3u8", working: true },
  { id: 276, name: "Makkal TV", url: "http://5k8q87azdy4v-hls-live.wmncdn.net/MAKKAL/271ddf829afeece44d8732757fba1a66.sdp/index.m3u8", working: true },
  { id: 277, name: "Makkal TV Mono", url: "https://5k8q87azdy4v-hls-live.wmncdn.net/MAKKAL/271ddf829afeece44d8732757fba1a66.sdp/mono.m3u8", working: true },
  { id: 278, name: "Malar TV", url: "https://sscloud7.com/live/malartv/index.m3u8", working: true },
  { id: 279, name: "Malar TV Alangulam", url: "http://malartv.sscloud7.in/malartv/malartv/index.m3u8", working: true },
  { id: 280, name: "Malar TV Surandai", url: "http://malartv.sscloud7.in/malartv/malartv/index.m3u8", working: true },
  { id: 281, name: "Malathi TV", url: "https://ipcloud.live/malathitv/malathitvhd/index.m3u8", working: true },
  { id: 282, name: "Manasu TV", url: "https://stream6.livebox.co.in/manasutvhls/live.m3u8", working: true },
  { id: 283, name: "Mangalam TV", url: "http://mangalamtv.phoenixcreations.online/mangalamtv/mangalam/playlist.m3u8", working: true },
  { id: 284, name: "Mangalam TV", url: "http://mangalamtv.phoenixcreations.online/mangalamtv/mangalam/playlist.m3u8", working: true },
  { id: 285, name: "Mapa TV", url: "https://play.applelive.in/mapatv/mapatv.m3u8", working: true },
  { id: 286, name: "Maran TV", url: "https://server.sscloud7.in/marantv/marantv/index.m3u8", working: true },
  { id: 287, name: "Mariya Annai TV", url: "https://play.applelive.in/mariyaannaitv/mariyaannaitv.m3u8", working: true },
  { id: 288, name: "Mariya Matha TV", url: "https://play.applelive.in/mariyamathatv/mariyamathatv.m3u8", working: true },
  { id: 289, name: "Mariye Vazhga TV", url: "https://live1.sscloud7.in/live/mariyevazhgatv/index.m3u8", working: true },
  { id: 290, name: "Maruthi TV HD", url: "https://stream.onecloudlive.in/maruthitv/maruthitvhd/index.m3u8", working: true },
  { id: 291, name: "Matha TV", url: "https://live.mathatv.in/mathatv/mathatv/index.m3u8", working: true },
  { id: 292, name: "Mathi TV", url: "https://notvstream.in/mathitv/mathitv/index.m3u8", working: true },
  { id: 293, name: "Mayuri TV", url: "https://server.sscloud7.in/live/mayuritvtvl/index.m3u8", working: true },
  { id: 294, name: "MCN TV", url: "https://play.applelive.in/mcntv/mcntv.m3u8", working: true },
  { id: 295, name: "ME24 Tamil [RojaTV]", url: "https://stream.rojatv.cloud/ME24TAMIL/onecloud/index.m3u8", working: true },
  { id: 296, name: "Meialai TV", url: "https://view.rcserver.in/tmp_hls21/meialai/index.m3u8", working: true },
  { id: 297, name: "Meiveli TV", url: "https://meiveli.livebox.co.in/MEIVELIMAINhls/meivelimain.m3u8", working: true },
  { id: 298, name: "Minnal TV", url: "https://ipcloud.live/app/minnaltv/minnalhd/index.m3u8", working: true },
  { id: 299, name: "MKP TV", url: "http://103.219.206.189:1935/mkptv/myStream/playlist.m3u8", working: true },
  { id: 300, name: "MKP TV", url: "http://mkpcloud.publicvm.com:1935/mkptv/myStream/playlist.m3u8", working: true },
  { id: 301, name: "MKP TV 2", url: "http://mkpcloud.publicvm.com:1935/mkptv/myStream/playlist.m3u8", working: true },
  { id: 302, name: "MM Classic", url: "http://103.78.164.62:8090/MMCLASSIC/index.m3u8", working: true },
  { id: 303, name: "MM Classic", url: "http://103.78.164.62:8090/MMCLASSIC/index.m3u8", working: true },
  { id: 304, name: "MM TV", url: "http://103.78.164.62:8090/MMTVHD/index.m3u8", working: true },
  { id: 305, name: "MM TV", url: "http://103.78.164.62:8090/MMTVHD/index.m3u8", working: true },
  { id: 306, name: "MM TV HD", url: "https://ipcloud.live/mmtv/mmtvhd/index.m3u8", working: true },
  { id: 307, name: "MN TV", url: "https://mntv.livebox.co.in/mntvhls/live.m3u8", working: true },
  { id: 308, name: "MN TV 2", url: "http://mntv.livebox.co.in/mntvhls/live.m3u8", working: true },
  { id: 309, name: "Mon Tamil Cinema", url: "http://198.144.149.206:8080/MONTAMIL_CINEMA/index.m3u8?token=GTR", working: true },
  { id: 310, name: "Moon TV", url: "https://live.sscloud7.in/live/moontv/index.m3u8", working: true },
  { id: 311, name: "Moon TV [MaxTN]", url: "https://live.maxtn.in/moontv/moontv/index.m3u8", working: true },
  { id: 312, name: "MS Live Stream", url: "http://player.mslivestream.net/tamil/ac206e74d75b285755ee4924df87d951.sdp/index.m3u8", working: true },
  { id: 313, name: "MS Mathan TV", url: "http://madhantv.phoenixcreations.online/madhantv/madhantv/index.m3u8", working: true },
  { id: 314, name: "MSN TV", url: "https://ipcloud.live/msntv/msntv/index.m3u8", working: true },
  { id: 315, name: "Mullai TV", url: "https://live.apcloud.in/mullaitv/live/index.m3u8", working: true },
  { id: 316, name: "My Faith TV", url: "https://stream.iplive.xyz/faithtv/faithtv/index.m3u8", working: true },
  { id: 317, name: "N TV", url: "https://galaxyott.live/hls/ntv.m3u8", working: true },
  { id: 318, name: "N TV 3", url: "http://ntv.phoenixcreations.online/ntv/ntv/playlist.m3u8", working: true },
  { id: 319, name: "N TV 4", url: "https://stream.sscloud7.in/live/ntv/index.m3u8", working: true },
  { id: 320, name: "Naga TV", url: "http://nagatv.phoenixcreations.online/nagatv/nagatv/index.m3u8", working: true },
  { id: 321, name: "Naga TV", url: "http://nagatv.phoenixcreations.online/nagatv/nagatv/index.m3u8", working: true },
  { id: 322, name: "Nakshatra", url: "https://rtmp.bmlive.net/stream/nakshatra/index.m3u8", working: true },
  { id: 323, name: "Namathu Sangamam TV", url: "http://yours.7starcloud.com:1935/live/nmtv/playlist.m3u8", working: true },
  { id: 324, name: "Namma Gobi TV", url: "https://stream.rojatv.cloud/nammagobi/tv/index.m3u8", working: true },
  { id: 325, name: "Nanjil Natham TV", url: "https://play.applelive.in/hls/nanjilnathamtv.m3u8", working: true },
  { id: 326, name: "NB TV", url: "https://rojatv.cloud/nbtv/nbtv/index.m3u8", working: true },
  { id: 327, name: "NDTV 24x7", url: "https://ndtv24x7elemarchana.akamaized.net/hls/live/2003678/ndtv24x7/master.m3u8", working: true },
  { id: 328, name: "Nellai TV", url: "https://stream.onecloudlive.in/nellaitv/nellaitv/index.m3u8", working: true },
  { id: 329, name: "New Channel Src", url: "https://iptvhls.inet.moe/hls/newchannel_src/index.m3u8", working: true },
  { id: 330, name: "Nijam TV", url: "http://nijamtv.indiamatrix.in/nijamtv/nijamtv.m3u8", working: true },
  { id: 331, name: "Nijam TV", url: "https://nijamtv.nijamtv.org/live/nijamtv/index.m3u8", working: true },
  { id: 332, name: "Nijam TV [IndiaMatrix]", url: "https://nijamtv.indiamatrix.in/nijamtv/nijamtv.m3u8", working: true },
  { id: 333, name: "Nila TV", url: "https://live.olidigital.in/nilatv/nilatv/index.m3u8", working: true },
  { id: 334, name: "Nisha TV", url: "http://103.159.180.5:1935/live/nisha/live.m3u8", working: true },
  { id: 335, name: "Nisha TV", url: "http://103.159.180.5:1935/live/nisha/live.m3u8", working: true },
  { id: 336, name: "Nithya Velicham TV", url: "https://play.applelive.in/nithyavelichamtv/nithyavelichamtv.m3u8", working: true },
  { id: 337, name: "NM TV", url: "http://yours.7starcloud.com:1935/live/nmtv/playlist.m3u8", working: true },
  { id: 338, name: "Nova JC TV", url: "https://ipcloud.live/novamani/jctv/index.m3u8", working: true },
  { id: 339, name: "NRS TV", url: "https://notvstream.in/nrstv/nrstv/index.m3u8", working: true },
  { id: 340, name: "NTN TV", url: "https://live.skystream.in/live/ntntv/index.m3u8?hls_ctx=1314owa2", working: true },
  { id: 341, name: "NTN TV 2", url: "https://live.skystream.in/live/ntntv/index.m3u8", working: true },
  { id: 342, name: "NTV Nellai", url: "http://ntv.phoenixcreations.online/ntv/ntv/index.m3u8", working: true },
  { id: 343, name: "NTV Nellai", url: "http://ntv.phoenixcreations.online/ntv/ntv/index.m3u8", working: true },
  { id: 344, name: "NTV PKT", url: "https://stream.galaxyott.live/live/ntvpkt/index.m3u8", working: true },
  { id: 345, name: "NTV Trichy", url: "https://notvstream.in/ntv/ntv/index.m3u8", working: true },
  { id: 346, name: "Ohm TV", url: "https://live1.sscloud7.in/live/ohmtv/playlist.m3u8", working: true },
  { id: 347, name: "Oli TV", url: "https://live.olidigital.in/olitv/olitv/index.m3u8", working: true },
  { id: 348, name: "Om Sakthi TV [1Cloud]", url: "https://stream.onecloudlive.in/omsakthitv/omsakthitv/index.m3u8", working: true },
  { id: 349, name: "Om TV", url: "http://omtv.7starcloud.com:1935/omtv/live/live.m3u8", working: true },
  { id: 350, name: "OM TV", url: "http://omtv.7starcloud.com:1935/omtv/live/live.m3u8", working: true },
  { id: 351, name: "OMM TV", url: "https://web.applelive.in/ommtv/ommtv/index.m3u8", working: true },
  { id: 352, name: "Orange TV", url: "https://notvstream.in/orangetv/orangetv/index.m3u8", working: true },
  { id: 353, name: "Oscar TV", url: "https://account21.livebox.co.in/oscartvhls/live.m3u8", working: true },
  { id: 354, name: "Params TV", url: "http://shreeparams.7starcloud.com:1935/live/paramstv/live.m3u8", working: true },
  { id: 355, name: "Params TV", url: "http://stream.ashokadigital.net/ashokaslm/paramstv/index.m3u8", working: true },
  { id: 356, name: "Params TV", url: "http://stream.ashokadigital.net/ashokaslm/paramstv/index.m3u8", working: true },
  { id: 357, name: "PCN GTV", url: "https://pcntv.wmsdigital.in/hls/gtv/stream.m3u8", working: true },
  { id: 358, name: "Penguin HD", url: "https://play.applelive.in/penguinhd/penguinhd.m3u8", working: true },
  { id: 359, name: "Peniel TV", url: "http://indiamatrix.in/penieltv/penieltv.m3u8", working: true },
  { id: 360, name: "PG TV", url: "https://app.xstream.onecloudlive.in/pgtv/pgtvhd/index.m3u8", working: true },
  { id: 361, name: "Phoenix 2", url: "http://phoenix.phoenixcreations.online/phoenix/phoenix/playlist.m3u8", working: true },
  { id: 362, name: "Phoenix Creations", url: "http://phoenix.phoenixcreations.online/phoenix/phoenix/index.m3u8", working: true },
  { id: 363, name: "Phoenix TV", url: "https://stream.onecloudlive.in/phoenixtv/phoenixtv/index.m3u8", working: true },
  { id: 364, name: "Phoenix TV", url: "http://phoenix.phoenixcreations.online/phoenix/phoenix/index.m3u8", working: true },
  { id: 365, name: "Phoenix TV [TamilStream]", url: "https://phoenix-hs-ott.tamilstream.in/phoenix/phoenix/playlist.m3u8", working: true },
  { id: 366, name: "Phoenix TV 2", url: "http://phoenixtv.stream.onecloudlive.in:8080/phoenixtv/phoenixtv/index.m3u8", working: true },
  { id: 367, name: "Polimer Channel", url: "http://polimer.7starcloud.com:1935/polimer/live/live.m3u8", working: true },
  { id: 368, name: "Polimer TV", url: "http://polimer.7starcloud.com:1935/polimer/live/live.m3u8", working: true },
  { id: 369, name: "PR TV", url: "https://play.applelive.in/prtv/prtv.m3u8", working: true },
  { id: 370, name: "Praise TV", url: "https://play.applelive.in/praisetv/praisetv.m3u8", working: true },
  { id: 371, name: "Prime Music", url: "https://live.primestream.in/prime/music/index.m3u8", working: true },
  { id: 372, name: "Prime TV", url: "https://live.applelive.in/primetv/primetv/index.m3u8", working: true },
  { id: 373, name: "Punnagai Desam TV", url: "http://punnagaidesamtv.phoenixcreations.online/punnagaidesamtv/punnagaidesamtv/playlist.m3u8", working: true },
  { id: 374, name: "Punnagai Desam TV", url: "http://punnagaidesamtv.phoenixcreations.online/punnagaidesamtv/punnagaidesamtv/playlist.m3u8", working: true },
  { id: 375, name: "Q TV", url: "http://103.78.164.62:8090/QTVHD/index.m3u8", working: true },
  { id: 376, name: "Q TV [Ashoka Digital]", url: "https://app.ashokadigital.net/app/71b64f7b/index.m3u8", working: true },
  { id: 377, name: "Qmax TV", url: "https://view.rcserver.in/tmp_hls22/qmaxtv/index.m3u8", working: true },
  { id: 378, name: "QTV HD", url: "http://103.78.164.62:8090/QTVHD/index.m3u8", working: true },
  { id: 379, name: "Queens TV", url: "https://notvstream.in/queens/queens/index.m3u8", working: true },
  { id: 380, name: "R Plus TV", url: "http://rplustv.stream.onecloudlive.in:8080/rplustv/rplustvhd/index.m3u8", working: true },
  { id: 381, name: "R Plus TV", url: "http://rplustv.stream.onecloudlive.in:8080/rplustv/rplustvhd/index.m3u8", working: true },
  { id: 382, name: "Raagam TV HD", url: "https://stream.onecloudlive.in/raagamtv/raagamtvhd/index.m3u8", working: true },
  { id: 383, name: "Raga TV", url: "https://live.onecloudlive.in/ragatv/ragatvhd/index.m3u8", working: true },
  { id: 384, name: "Ragamm TV", url: "https://account26.livebox.co.in/RAGAMMTPhls/live.m3u8", working: true },
  { id: 385, name: "Raghul TV", url: "https://live1.sscloud7.in/live/raghultv/index.m3u8", working: true },
  { id: 386, name: "Rainbow TV", url: "https://cloudstream4k.com/rainbowtv/ssdslive/playlist.m3u8", working: true },
  { id: 387, name: "Raja TV", url: "http://rajatv.phoenixcreations.online/rajatv/raja/playlist.m3u8", working: true },
  { id: 388, name: "Raja TV Valliyur", url: "http://rajatv.phoenixcreations.online/rajatv/raja/playlist.m3u8", working: true },
  { id: 389, name: "Ramya TV", url: "http://brightmeltech.in/ramyatv/ramyatv.m3u8", working: true },
  { id: 390, name: "Ramya TV", url: "http://live.brightmeltech.in/ramyatv/ramyatv.m3u8", working: true },
  { id: 391, name: "Ratchagar TV", url: "http://ratchagartv.phoenixcreations.online/ratchagartv/ratchagar/index.m3u8", working: true },
  { id: 392, name: "Rathchagar TV", url: "http://ratchagartv.phoenixcreations.online/ratchagartv/ratchagar/index.m3u8", working: true },
  { id: 393, name: "Rio TV", url: "http://ipcloud.live/riotv/riotvhd/index.m3u8", working: true },
  { id: 394, name: "Rio TV HD", url: "https://ipcloud.live/riotv/riotvhd/index.m3u8", working: true },
  { id: 395, name: "Rio TV HD 2", url: "http://ipcloud.live/riotv/riotvhd/index.m3u8", working: true },
  { id: 396, name: "Rio TV Max", url: "https://stream.onecloudlive.in/riotv/riotvmax/index.m3u8", working: true },
  { id: 397, name: "RK TV", url: "http://rktv.phoenixcreations.online/rktv/rktv/index.m3u8", working: true },
  { id: 398, name: "RK TV", url: "http://rktv.phoenixcreations.online/rktv/rktv/index.m3u8", working: true },
  { id: 399, name: "RK TV [TamilStream]", url: "https://rktv-hs1.tamilstream.in/rktv/tenkasi/playlist.m3u8", working: true },
  { id: 400, name: "Rock TV", url: "https://apis.avmediawork.in/tvhls/rocktv.m3u8", working: true },
  { id: 401, name: "Rock TV [OTTLive]", url: "https://stream.ottlive.co.in/suriyantvtamil/index.m3u8", working: true },
  { id: 402, name: "Roja Movies", url: "https://live.rojatv.cloud/rojamovies/rojamovies/index.m3u8", working: true },
  { id: 403, name: "Roja Movies", url: "https://hls.rojatv.cloud/rojamovies/rojamovies/index.m3u8", working: true },
  { id: 404, name: "Roja Movies [Alt]", url: "https://stream.rojatv.cloud/rojatv/rojatv/index.m3u8", working: true },
  { id: 405, name: "Roja TV", url: "https://hls.rojatv.cloud/rojatv/rojatv/index.m3u8", working: true },
  { id: 406, name: "Roja TV", url: "http://rojatv.phoenixcreations.online/rojatv/rojatv/index.m3u8", working: true },
  { id: 407, name: "Roja TV 1", url: "https://live.rojatv.cloud/rojatv/rojatv/index.m3u8", working: true },
  { id: 408, name: "Roja TV 3", url: "http://rojatv.phoenixcreations.online/rojatv/rojatv/index.m3u8", working: true },
  { id: 409, name: "Roja TV 4", url: "https://rojatv.cloud/rojatv/rojatv/index.m3u8", working: true },
  { id: 410, name: "Roja TV 6", url: "http://rojatv.phoenixcreations.online/rojatv/rojatv/playlist.m3u8", working: true },
  { id: 411, name: "Royal TV", url: "https://play.applelive.in/royaltv/royaltv.m3u8", working: true },
  { id: 412, name: "Ruhasha TV", url: "https://live.applelive.in/ruhashatv/ruhashatv/index.m3u8", working: true },
  { id: 413, name: "S Max TV", url: "http://play.applelive.in/smaxtv/smaxtv.m3u8", working: true },
  { id: 414, name: "S TV", url: "https://play.applelive.in/stv/stv.m3u8", working: true },
  { id: 415, name: "Sabari TV HD", url: "https://stream.onecloudlive.in/sabaritv/sabaritvhd/index.m3u8", working: true },
  { id: 416, name: "Sachin TV Music HD", url: "https://ipcloud.live/sachintv/musichd/index.m3u8", working: true },
  { id: 417, name: "Sahara TV HD", url: "https://ipcloud.live/saharatv/saharatvhd/index.m3u8", working: true },
  { id: 418, name: "Sai TV Madurai (NOTV)", url: "http://198.144.149.206:8080/NOTV/SAITVMD/index.m3u8?token=GTR", working: true },
  { id: 419, name: "Sai TV Madurai [NOTV]", url: "http://198.144.149.206:8080/NOTV/SAITVMD/index.m3u8?token=GTR", working: true },
  { id: 420, name: "Sai TV MD", url: "http://198.144.149.206:8080/NOTV/SAITVMD/tracks-v1a1/mono.m3u8?token=GTR", working: true },
  { id: 421, name: "Sai TV Tenkasi", url: "http://saitv.sscloud7.in/live/livesaitv/index.m3u8", working: true },
  { id: 422, name: "Sailam TV", url: "https://stream.onecloudlive.in/sailamtv/sailamtv/index.m3u8", working: true },
  { id: 423, name: "Sakthi TV", url: "https://live.sscloud7.in/live/sakthitv/index.m3u8", working: true },
  { id: 424, name: "Sakthi TV Sambavarvadakarai", url: "https://stream.onecloudlive.in/sachintv/sakthitv/index.m3u8", working: true },
  { id: 425, name: "Salvation TV", url: "https://ktismaservers.in:3902/live/salvationtvlive.m3u8", working: true },
  { id: 426, name: "Samugam", url: "https://ca.streamjo.com/live/samugam.m3u8", working: true },
  { id: 427, name: "Sana Plus", url: "https://galaxyott.live/hls/sanaplus.m3u8", working: true },
  { id: 428, name: "Sana Plus [OTTLive]", url: "https://stream.ottlive.co.in/sanaplus/index.m3u8", working: true },
  { id: 429, name: "Sana TV", url: "https://galaxyott.live/hls/sanatv.m3u8", working: true },
  { id: 430, name: "Sana TV", url: "https://stream.galaxyott.live/live/sanatv/index.m3u8", working: true },
  { id: 431, name: "Sana TV [DistroTV]", url: "https://d35j504z0x2vu2.cloudfront.net/v1/master/0bc8e8376bd8417a1b6761138aa41c26c7309312/sana-tv/index.m3u8?ads.vf=VcGQSvUuGWi", working: true },
  { id: 432, name: "Sana TV [OTTLive]", url: "https://stream.ottlive.co.in/sanatv/index.m3u8", working: true },
  { id: 433, name: "Sana TV [YuppTV]", url: "https://vglivessai.akamaized.net/us/v1/master/611d79b11b77e2f571934fd80ca1413453772ac7/b6d9e864-ec16-410a-804d-ccf8f720bfaa/index.m3u8", working: true },
  { id: 434, name: "Sangamam TV Erode [RojaTV]", url: "https://stream.rojatv.cloud/SANGAMAMTV/onecloud/index.m3u8", working: true },
  { id: 435, name: "Santhiya TV HD", url: "https://stream.onecloudlive.in/santhiyatv/santhiyatvhd/index.m3u8", working: true },
  { id: 436, name: "Santhiya TV JKM", url: "https://stream.onecloudlive.in/santhiyatv/jkm/index.m3u8", working: true },
  { id: 437, name: "SAR TV", url: "http://sartv.phoenixcreations.online/sartv/sartv/index.m3u8", working: true },
  { id: 438, name: "SAR TV [Alt]", url: "http://sartv2.phoenixcreations.online/sartv2/sartv2/playlist.m3u8", working: true },
  { id: 439, name: "SAR TV 2", url: "http://sartv.phoenixcreations.online/sartv/sartv/playlist.m3u8", working: true },
  { id: 440, name: "SAR TV Valliyur", url: "http://sartv.phoenixcreations.online/sartv/sartv/index.m3u8", working: true },
  { id: 441, name: "Sarvik TV", url: "https://live3.onecloudlive.in/sachintv/sarvikhd/index.m3u8", working: true },
  { id: 442, name: "Sasi TV", url: "http://sasitv.phoenixcreations.online/sasitv/sasitv/index.m3u8", working: true },
  { id: 443, name: "Sasi TV", url: "http://sasitv.phoenixcreations.online/sasitv/sasitv/index.m3u8", working: true },
  { id: 444, name: "Selfee TV", url: "https://play.applelive.in/selfeetv/selfeetv.m3u8", working: true },
  { id: 445, name: "Selva Tamil TV", url: "https://stream.sscloud7.in/live/selvatamiltv/index.m3u8", working: true },
  { id: 446, name: "Senthur TV", url: "http://senthurtv.phoenixcreations.online/senthurtv/senthurtv/playlist.m3u8", working: true },
  { id: 447, name: "Senthur TV", url: "http://senthurtv.phoenixcreations.online/senthurtv/senthurtv/playlist.m3u8", working: true },
  { id: 448, name: "Sha TV", url: "https://play.applelive.in/shatv/shatv.m3u8", working: true },
  { id: 449, name: "Sha TV 2", url: "http://applelive.in/shatv/shatv.m3u8", working: true },
  { id: 450, name: "Shakthi Channel", url: "https://cloudstream4k.com/shakthihd/bsk/playlist.m3u8", working: true },
  { id: 451, name: "Shalini TV", url: "https://ipcloud.live/shalinitv/shalinitv/index.m3u8", working: true },
  { id: 452, name: "Shalini TV 2", url: "https://stream.singamcloud.in/shalinitv/shalinitv/index.m3u8", working: true },
  { id: 453, name: "Shalini TV 4", url: "http://ipcloud.live:8080/shalinitv/shalinitv/index.m3u8", working: true },
  { id: 454, name: "Shalini TV Kanchipuram", url: "http://103.78.164.62:8090/SHALINITVHD/index.m3u8", working: true },
  { id: 455, name: "Shalini TV Kanchipuram", url: "http://103.78.164.62:8090/SHALINITVHD/index.m3u8", working: true },
  { id: 456, name: "Silver Sat Media", url: "http://v.7starcloud.com:1935/live/ssatnews/playlist.m3u8", working: true },
  { id: 457, name: "Singam TV", url: "http://brightmeltech.in/singamtv/singamtv.m3u8", working: true },
  { id: 458, name: "Sirustigar TV", url: "http://indiamatrix.in/sirustigartv/sirustigartv.m3u8", working: true },
  { id: 459, name: "Sivan TV", url: "http://sivantv.livebox.co.in/sivantvhls/sivan.m3u8", working: true },
  { id: 460, name: "SK TV", url: "https://stream.galaxyott.live/live/sktv/index.m3u8", working: true },
  { id: 461, name: "SK TV Karur", url: "https://view.rcserver.in/tmp_hls24/sktv/index.m3u8", working: true },
  { id: 462, name: "Sky Media", url: "http://skymedia.phoenixcreations.online/skymedia/skymedia/index.m3u8", working: true },
  { id: 463, name: "Sky Media", url: "http://skymedia.phoenixcreations.online/skymedia/skymedia/index.m3u8", working: true },
  { id: 464, name: "Sky TV", url: "https://ipcloud.live/skytv/skytv/index.m3u8", working: true },
  { id: 465, name: "Sky TV 2", url: "https://sscloud7.com/live/skytv/index.m3u8", working: true },
  { id: 466, name: "Sky TV Karur", url: "https://view.rcserver.in/tmp_hls11/skytv/index.m3u8", working: true },
  { id: 467, name: "Smart Sri", url: "https://mumbai-edge.smartplaytv.in/smartsri/index.m3u8", working: true },
  { id: 468, name: "Smax TV", url: "http://play.applelive.in/smaxtv/smaxtv.m3u8", working: true },
  { id: 469, name: "Smax TV 2", url: "http://applelive.in/smaxtv/smaxtv.m3u8", working: true },
  { id: 470, name: "SMCV TV", url: "https://singamcloud.in/smcvtv/smcvtv/index.m3u8", working: true },
  { id: 471, name: "SMCV TV 2", url: "http://singamcloud.in/smcvtv/smcvtv/index.m3u8", working: true },
  { id: 472, name: "Sooriyan TV", url: "https://live20.bozztv.com/giatv/giatv-Infinittyott/Infinittyott/playlist.m3u8", working: true },
  { id: 473, name: "Sooriyan TV Cinema", url: "https://live20.bozztv.com/giatv/giatv-Sooriyantv/Sooriyantv/playlist.m3u8", working: true },
  { id: 474, name: "SR Music", url: "http://srnet.bmlive.net:1935/srmusic/myStream/playlist.m3u8", working: true },
  { id: 475, name: "SR Musix", url: "http://srnet.bmlive.net:1935/srmusic/myStream/playlist.m3u8", working: true },
  { id: 476, name: "SR TV", url: "https://web.applelive.in/stream/srtv/index.m3u8", working: true },
  { id: 477, name: "Sri Arjun TV", url: "https://stream.onecloudlive.in/sriarjuntv/sriarjun/index.m3u8", working: true },
  { id: 478, name: "Sri Bhagavan", url: "https://ipcloud.live/sriarjuntv/sribhagavan/index.m3u8", working: true },
  { id: 479, name: "Sri Krishna TV", url: "http://103.110.236.141:8080/hls/erodekrishnatv/index.m3u8", working: true },
  { id: 480, name: "Sri Sai", url: "https://annainew.livebox.co.in/srisaihls/live.m3u8", working: true },
  { id: 481, name: "Sri Vasanth TV", url: "https://play.applelive.in/vasanthtv/vasanthtv.m3u8", working: true },
  { id: 482, name: "SS HD", url: "https://server.sscloud7.in/live/sshd/playlist.m3u8", working: true },
  { id: 483, name: "SS HD 2", url: "https://server.sscloud7.in/live/sshd/index.m3u8", working: true },
  { id: 484, name: "SS TV", url: "https://notvstream.in/sstv/sstv/index.m3u8", working: true },
  { id: 485, name: "SS TV", url: "https://sstv-ott.tamilstream.in/sstv/sstv/playlist.m3u8", working: true },
  { id: 486, name: "SSCN TV", url: "https://stream.ashokadigital.net/sscn/sscn/index.m3u8", working: true },
  { id: 487, name: "Star Media", url: "https://rtmp.notvstream.in/starmedia/starmedia/index.m3u8", working: true },
  { id: 488, name: "STM TV", url: "https://live.sscloud7.in/stmtv/srithangamalaimurugantv/index.m3u8", working: true },
  { id: 489, name: "STN TV", url: "https://play.applelive.in/stntv/stntv.m3u8", working: true },
  { id: 490, name: "STN TV HD", url: "https://play.applelive.in/stntv/stntvhd.m3u8", working: true },
  { id: 491, name: "Stream Hoster Pl 118", url: "https://2-fss-2.streamhoster.com/pl_118/203324-1410936-1/chunklist.m3u8", working: true },
  { id: 492, name: "STV", url: "https://apis.avmediawork.in/tvhls/stv.m3u8", working: true },
  { id: 493, name: "STV HD", url: "https://stream.onecloudlive.in/stv/stvhd/index.m3u8", working: true },
  { id: 494, name: "Subash TV", url: "http://subash.phoenixcreations.online/subash/subash/index.m3u8", working: true },
  { id: 495, name: "Subash TV Tenkasi", url: "http://subash.phoenixcreations.online/subash/subash/index.m3u8", working: true },
  { id: 496, name: "Subash TV Tenkasi [Cloud7]", url: "https://server.sscloud7.in/live/subashhd/index.m3u8", working: true },
  { id: 497, name: "Subi TV", url: "https://notvstream.in/subitv/subitv/index.m3u8", working: true },
  { id: 498, name: "Subin TV", url: "https://stream.galaxyott.live/live/subintv/index.m3u8", working: true },
  { id: 499, name: "Subin TV (Phoenix)", url: "http://subintv.phoenixcreations.online/subintv/subintv/playlist.m3u8", working: true },
  { id: 500, name: "Subin TV [OTTLive]", url: "https://stream.ottlive.co.in/subintvtamil/index.m3u8", working: true },
  { id: 501, name: "Subin TV [Phoenix]", url: "http://subintv.phoenixcreations.online/subintv/subintv/playlist.m3u8", working: true },
  { id: 502, name: "Success TV HD", url: "https://stream.onecloudlive.in/successtv/successtvhd/index.m3u8", working: true },
  { id: 503, name: "Super TV", url: "https://stream.rojatv.cloud/super/tv/index.m3u8", working: true },
  { id: 504, name: "Super TV", url: "https://stream.onecloudlive.in/superstartv/superstarhd/index.m3u8", working: true },
  { id: 505, name: "Super TV Dindigul", url: "http://122.165.249.163:8080/hls/supertv/index.m3u8", working: true },
  { id: 506, name: "Super TV Dindigul", url: "http://122.165.249.163:8080/hls/supertv/index.m3u8", working: true },
  { id: 507, name: "Suriya TV", url: "https://ipcloud.live/nellaitv/suriyatv/index.m3u8", working: true },
  { id: 508, name: "Suriya TV [OTTLive]", url: "https://stream.ottlive.co.in/suryatvtamil/index.m3u8", working: true },
  { id: 509, name: "Suriyan TV", url: "https://view.rcserver.in/tmp_hls9/suriyantv/index.m3u8", working: true },
  { id: 510, name: "Suriyan TV 2", url: "https://stream.sscloud7.com/live/suriyantv/index.m3u8", working: true },
  { id: 511, name: "Surya TV", url: "https://galaxyott.live/hls/suryatv.m3u8", working: true },
  { id: 512, name: "Surya TV 2", url: "https://galaxyott.live//hls//suryatv.m3u8", working: true },
  { id: 513, name: "T Thirai", url: "https://tn.streamezy.in/hls/tthirai/live.m3u8", working: true },
  { id: 514, name: "Tamil Magan TV", url: "http://120.138.14.16:8080/hls/tamilmagantv/index.m3u8", working: true },
  { id: 515, name: "Tamil Magan TV", url: "http://120.138.14.16:8080/hls/tamilmagantv/index.m3u8", working: true },
  { id: 516, name: "Tamil Star TV", url: "http://acv.7starcloud.com:1935/tamilstar/tv/playlist.m3u8", working: true },
  { id: 517, name: "Tamil Star TV", url: "http://acv.7starcloud.com:1935/tamilstar/tv/playlist.m3u8", working: true },
  { id: 518, name: "Tamil Vision International", url: "https://live.cmr24.fm/TVI/HD/playlist.m3u8", working: true },
  { id: 519, name: "Tamilnesan TV", url: "https://view.rcserver.in/tmp_hls14/tntv/index.m3u8", working: true },
  { id: 520, name: "TCBN TV Live", url: "https://ktismaservers.in:3382/live/tcbntvlive.m3u8", working: true },
  { id: 521, name: "TDN", url: "https://live.maxtn.in/tdn/tdn/index.m3u8", working: true },
  { id: 522, name: "Test Source", url: "https://iptvhls.inet.moe/hls/test_src/index.m3u8", working: true },
  { id: 523, name: "Thaai TV", url: "https://ap02.iqplay.tv:8082/hls/thailive/playlist.m3u8", working: true },
  { id: 524, name: "Thalaa TV", url: "https://streams2.sofast.tv/ptnr-yupptv/title-THALAA-TV-TAM_yupptv/v1/master/611d79b11b77e2f571934fd80ca1413453772ac7/2069c593-3c07-4d62-9d44-746be5c3a5d6/manifest.m3u8", working: true },
  { id: 525, name: "Thamilaaram TV", url: "https://thamilaaramtv24-hls.secdn.net/thamilaaramtv24-channel/play/ThamilaaramTV.smil/playlist.m3u8", working: true },
  { id: 526, name: "Thangam TV", url: "https://stream.onecloudlive.in/thangamtv/thangamtvhd/index.m3u8", working: true },
  { id: 527, name: "Tharun Movies", url: "https://streaming.livebox.co.in/tharunmovieshls/live.m3u8", working: true },
  { id: 528, name: "Thendral TV", url: "https://live.thendralcloud.in/thendraltv/d0dbe915091d400bd8ee7f27f0791303.sdp/chunks.m3u8", working: true },
  { id: 529, name: "Thendral TV 6", url: "https://live.thendralcloud.in/thendraltv/d0dbe915091d400bd8ee7f27f0791303.sdp/playlist.m3u8", working: true },
  { id: 530, name: "Thendral TV Alangulam", url: "http://almthendraltv.phoenixcreations.online/almthendraltv/almthendraltv/playlist.m3u8", working: true },
  { id: 531, name: "Thendral TV Ambai", url: "http://thendraltv.phoenixcreations.online/thendraltv/thendraltv/index.m3u8", working: true },
  { id: 532, name: "Thendral TV Ambai", url: "http://thendraltv.phoenixcreations.online/thendraltv/thendraltv/index.m3u8", working: true },
  { id: 533, name: "Thendral TV Chennai", url: "https://stream.ashokadigital.net/thendraltv/thendraltv/index.m3u8", working: true },
  { id: 534, name: "Thendral TV Madurai", url: "https://w6oy7zkpdxrg-hls-live.5centscdn.com/THENDRALHD/aac0b08f91370cd39f61343d2b6e8069.sdp/playlist.m3u8", working: true },
  { id: 535, name: "Thendral TV Theni", url: "https://sscloud7.com/live/thendraltv/index.m3u8", working: true },
  { id: 536, name: "Thentamil TV", url: "http://thentv.stream.onecloudlive.in/thentv/thentvhd/index.m3u8", working: true },
  { id: 537, name: "Thentamil TV", url: "http://thentv.stream.onecloudlive.in/thentv/thentvhd/index.m3u8", working: true },
  { id: 538, name: "Thirai Music HD", url: "https://live.apcloud.in/thiraimusic/thiraimusichd/index.m3u8", working: true },
  { id: 539, name: "Thirai TV", url: "https://view.apserver.in/tmp_hls2/thiraitv/index.m3u8", working: true },
  { id: 540, name: "Thirai TV HD", url: "https://live.apcloud.in/thiraitv/thiraitvhd/index.m3u8", working: true },
  { id: 541, name: "Thirai TV Plus", url: "https://view.apserver.in/tmp_hls1/thiraitvplus/index.m3u8", working: true },
  { id: 542, name: "Thirumalai TV", url: "https://notvstream.in/thirumalaitv/thirumalaitv/index.m3u8", working: true },
  { id: 543, name: "Three Star TV HD", url: "https://stream.onecloudlive.in/threestartv/threestarhd/index.m3u8", working: true },
  { id: 544, name: "Thuthi TV", url: "http://indiamatrix.in/thuthitv/thuthitv.m3u8", working: true },
  { id: 545, name: "Time TV", url: "https://live.olidigital.in/timetv/timetv/index.m3u8", working: true },
  { id: 546, name: "Tirupur Voice TV", url: "https://notvstream.in/tirupurvoicetv/tirupurvoicetv/index.m3u8", working: true },
  { id: 547, name: "Top TV HD", url: "https://stream.onecloudlive.in/toptv/toptvhd/index.m3u8", working: true },
  { id: 548, name: "TTN TV", url: "https://web.applelive.in/stream/ttntv/index.m3u8", working: true },
  { id: 549, name: "TWOC TV", url: "https://rtmp.applelive.in/twoctv/twoctv/index.m3u8", working: true },
  { id: 550, name: "U TV", url: "https://stream.galaxyott.live/live/utv/index.m3u8", working: true },
  { id: 551, name: "Udhayam TV", url: "https://view.rcserver.in/tmp_hls8/udhayamtv/index.m3u8", working: true },
  { id: 552, name: "Udhayam TV Karur", url: "https://view.rcserver.in/tmp_hls13/udhayamhd/index.m3u8", working: true },
  { id: 553, name: "Ultimate TV [OTTLive]", url: "https://stream.ottlive.co.in/utvtamil/index.m3u8", working: true },
  { id: 554, name: "Urchagam TV", url: "https://rtmp.bmlive.net/bms/urchagamtv/stream.m3u8", working: true },
  { id: 555, name: "Uthamiyae TV", url: "https://kali.vdopanel.com:3169/stream/play.m3u8", working: true },
  { id: 556, name: "UTV Anandam", url: "https://mumt02.tangotv.in/UTVANANDAM/index.m3u8", working: true },
  { id: 557, name: "UTV Coimbatore", url: "http://cdn.utvtamil.in/utvkovai/utv/playlist.m3u8", working: true },
  { id: 558, name: "UTV Kovai", url: "http://cdn.utvtamil.in/utvkovai/utv/playlist.m3u8", working: true },
  { id: 559, name: "UTV Mayuram", url: "https://notvstream.in/utv/utv/index.m3u8", working: true },
  { id: 560, name: "V Tamil", url: "https://hlsstream.olidigital.in/vtv/vtv/index.m3u8", working: true },
  { id: 561, name: "V Tamizh", url: "https://app.ashokadigital.net/app/89c09acf/index.m3u8", working: true },
  { id: 562, name: "Vaani TV", url: "http://vaanivisuals.in:1935/vaanitv/vaanitv/playlist.m3u8", working: true },
  { id: 563, name: "Vaani Visuals", url: "http://vaanivisuals.in:1935/vaanitv/vaanitv/playlist.m3u8", working: true },
  { id: 564, name: "Vajra TV", url: "https://app.ashokadigital.net/app/3b31be9f/index.m3u8", working: true },
  { id: 565, name: "Vajra TV (TACTV)", url: "http://mmtv.stream.onecloudlive.in/mmtv/vajratvtac/index.m3u8", working: true },
  { id: 566, name: "Vajram TV", url: "https://app.ashokadigital.net/app/68b001a0/index.m3u8", working: true },
  { id: 567, name: "Vani TV", url: "https://live.maxtn.in/vanitv/vanitv/index.m3u8", working: true },
  { id: 568, name: "Vasan TV", url: "https://play.applelive.in/vasantv/vasantv.m3u8", working: true },
  { id: 569, name: "Vasan TV 2", url: "http://applelive.in/vasantv/vasantv.m3u8", working: true },
  { id: 570, name: "Vasanam TV", url: "https://stream.sscloud7.com/live/mahimaitv/index.m3u8", working: true },
  { id: 571, name: "Vasanth TV", url: "http://applelive.in/vasanthtv/vasanthtv.m3u8", working: true },
  { id: 572, name: "VDS TV", url: "http://117.247.192.123:8080/vds/vds.m3u8?psk=123456", working: true },
  { id: 573, name: "VDS TV", url: "http://117.247.192.123:8080/vds/vds.m3u8?psk=123456", working: true },
  { id: 574, name: "Vedha TV", url: "https://skystream.in/live/vedha6528/index.m3u8", working: true },
  { id: 575, name: "Veera TV HD", url: "https://ipcloud.live/veeratv/veeratvhd/index.m3u8", working: true },
  { id: 576, name: "Veerali TV", url: "https://ipcloud.live/veerali/veeralitv/index.m3u8", working: true },
  { id: 577, name: "Velan TV", url: "http://velantv.phoenixcreations.online/velantv/velantv/index.m3u8", working: true },
  { id: 578, name: "Velan TV", url: "https://cloudstream4k.com/velantvhdkanchi/bsk/playlist.m3u8", working: true },
  { id: 579, name: "Velan TV", url: "http://velantv.phoenixcreations.online/velantv/velantv/index.m3u8", working: true },
  { id: 580, name: "Velavan TV", url: "http://velavantv.sscloud7.in/live/velavantv/index.m3u8", working: true },
  { id: 581, name: "Velavan TV", url: "https://server.sscloud7.in/live/velavantv/index.m3u8", working: true },
  { id: 582, name: "Velavan TV", url: "http://velavantv.sscloud7.in/live/velavantv/index.m3u8", working: true },
  { id: 583, name: "Vezhamugam TV", url: "http://live.mintv.in/vezhamugam/live/playlist.m3u8", working: true },
  { id: 584, name: "Vidyal TV", url: "https://account11.livebox.co.in/vidyaltvhls/live.m3u8?psk=stream", working: true },
  { id: 585, name: "Vidyal TV 2", url: "https://account11.livebox.co.in/vidyaltvhls/live.m3u8", working: true },
  { id: 586, name: "Vimal TV", url: "https://stream.onecloudlive.in/karthick/vimaltv/index.m3u8", working: true },
  { id: 587, name: "Vinayaga TV", url: "http://server.mindspell.in/live/vinayagatv/index.m3u8", working: true },
  { id: 588, name: "Vinayaga TV 3", url: "https://server.sscloud7.in/live/vinayagatv/index.m3u8", working: true },
  { id: 589, name: "Vinmeen Music", url: "https://vinmeentv.livebox.co.in/vinmeentvhls/live.m3u8", working: true },
  { id: 590, name: "Vinmeen TV", url: "http://vinmeentv.livebox.co.in/vinmeentvhls/live.m3u8", working: true },
  { id: 591, name: "Vinoth TV", url: "https://server.sscloud7.in/live/vinothtv/index.m3u8", working: true },
  { id: 592, name: "Visaka TV", url: "http://visaka.7starcloud.com:1935/live/visakatv/playlist.m3u8", working: true },
  { id: 593, name: "Visaka TV", url: "http://visaka.7starcloud.com:1935/live/visakatv/playlist.m3u8", working: true },
  { id: 594, name: "Vishil Max", url: "https://stream.sscloud7.in/live/vishiltv2/index.m3u8", working: true },
  { id: 595, name: "Vishil Max", url: "https://stream.sscloud7.in/live/vishiltv2/index.m3u8", working: true },
  { id: 596, name: "Voice TV HD", url: "https://stream.ashokadigital.net/voicetv/voicetvhd/index.m3u8", working: true },
  { id: 597, name: "VTV", url: "https://play.applelive.in/vtv/vtv.m3u8", working: true },
  { id: 598, name: "VTV Trichy", url: "http://198.144.149.206:8080/NOTV/VTV1/index.m3u8?token=GTR", working: true },
  { id: 599, name: "VTV Trichy", url: "http://198.144.149.206:8080/NOTV/VTV1/index.m3u8?token=GTR", working: true },
  { id: 600, name: "Web Aduga", url: "https://rtmp.bmlive.net/webaduga/webaduga/index.m3u8", working: true },
  { id: 601, name: "Win Vision TV", url: "http://applelive.in/winvisiontv/winvisiontv.m3u8", working: true },
  { id: 602, name: "Win Vision TV 2", url: "https://play.applelive.in/winvisiontv/winvisiontv.m3u8", working: true },
  { id: 603, name: "Yatra TV", url: "https://stream.onecloudlive.in/yatra/yatratv/index.m3u8", working: true },
  { id: 604, name: "Yeshua TV", url: "https://transcoding.livebox.co.in/Yeshuahls/live.m3u8", working: true },
  { id: 605, name: "Yet TV", url: "https://live.yettelevision.com:5443/LiveApp/streams/yettv.m3u8", working: true },
  { id: 606, name: "Yours TV", url: "http://yours.7starcloud.com:1935/live/yourstv/playlist.m3u8", working: true },
  { id: 607, name: "Yours TV", url: "http://yours.7starcloud.com:1935/live/yourstv/playlist.m3u8", working: true },
  { id: 608, name: "Yovan TV", url: "https://live1.sscloud7.in/live/yovantv/playlist.m3u8", working: true },
  { id: 609, name: "Aadhavan Colours [APServer]", url: "https://view.apserver.in/tmp_hls4/aadhavancolours/index.m3u8", working: false },
  { id: 610, name: "Aadhavan TV Colours", url: "https://live.olidigital.in/aadhavantvcolours/aadhavantvcolours/index.m3u8", working: false },
  { id: 611, name: "Aadhavan TV HD", url: "https://ipcloud.live/aadhavantv/aadhavanhd/index.m3u8", working: false },
  { id: 612, name: "Aadvik TV", url: "https://ipcloud.live/sachintv/aadviktv/index.m3u8", working: false },
  { id: 613, name: "Aanmika TV", url: "https://stream.onecloudlive.in/nilatvsvg/nilaomtv/index.m3u8", working: false },
  { id: 614, name: "Aarthi TV", url: "http://198.144.149.206:8080/NOTV/AARTHITV/index.m3u8?token=GTR", working: false },
  { id: 615, name: "Aarthi TV", url: "http://198.144.149.206:8080/NOTV/AARTHITV/index.m3u8?token=GTR", working: false },
  { id: 616, name: "Aaryaa TV (Jio)", url: "https://jiotvmblive.cdn.jio.com/bpk-tv/aryatvtamil/HLSPartner/index.m3u8", working: false },
  { id: 617, name: "Aaryaa TV [Cloud7]", url: "https://live.sscloud7.in/live/aaryaatv/index.m3u8", working: false },
  { id: 618, name: "ACP Isai Oli", url: "http://103.87.105.51:8080/acpisaioli/acpisaioli.m3u8?psk=123456", working: false },
  { id: 619, name: "ACP Isai Oli", url: "http://103.87.105.51:8080/acpisaioli/acpisaioli.m3u8?psk=123456", working: false },
  { id: 620, name: "Ajay TV", url: "https://server.sscloud7.in/live/ajaytv/index.m3u8", working: false },
  { id: 621, name: "Akash TV", url: "https://account2.livebox.co.in/AkashTvhls/live.m3u8", working: false },
  { id: 622, name: "Amman Plus", url: "https://app.ashokadigital.net/app/e39f503a/index.m3u8", working: false },
  { id: 623, name: "Anandham TV", url: "https://server.sscloud7.in/live/anandhamtv/index.m3u8", working: false },
  { id: 624, name: "Anbu TV", url: "https://rtmp.bmlive.net/bms/anbutvhd/index.m3u8", working: false },
  { id: 625, name: "Anbudan TV", url: "https://rtmp.applelive.in/anbudantv/anbudantv/index.m3u8", working: false },
  { id: 626, name: "Apple TV Kumbakonam", url: "https://view.rcserver.in/tmp_hls18/index.m3u8", working: false },
  { id: 627, name: "Apple TV Tirunelveli", url: "https://stream.iplive.xyz/mayatv/mayatv/index.m3u8", working: false },
  { id: 628, name: "Arputham TV", url: "https://live1.sscloud7.in/live/arputhamtv/index.m3u8", working: false },
  { id: 629, name: "Aso Chennai", url: "http://198.144.149.206:8080/NOTV/ASOSACHENNAI/index.m3u8?token=GTR", working: false },
  { id: 630, name: "Asoka TV", url: "http://ipcloud.live/asokatv/asokahd/index.m3u8", working: false },
  { id: 631, name: "Asoka TV HD", url: "http://ipcloud.live/asokatv/asokahd/index.m3u8", working: false },
  { id: 632, name: "AVS TV", url: "https://play.applelive.in/avstv/avstv.m3u8", working: false },
  { id: 633, name: "Ayya Vaikuntar TV", url: "https://server.sscloud7.in/live/ayyatv/index.m3u8", working: false },
  { id: 634, name: "Bakthi Tamil", url: "https://rtmp.bmlive.net/stream/bakthitamil/index.m3u8", working: false },
  { id: 635, name: "Bama TV", url: "http://indiamatrix.in/bamahd/bamahd.m3u8", working: false },
  { id: 636, name: "Bama TV", url: "http://indiamatrix.in/bamahd/bamahd.m3u8", working: false },
  { id: 637, name: "Bhagavath TV", url: "https://web.applelive.in/bhagavathtv/bhagavathtv/index.m3u8", working: false },
  { id: 638, name: "Bhagyam TV", url: "https://jiotvmblive.cdn.jio.com/bpk-tv/aanadhamtvtamil/HLSPartner/index.m3u8", working: false },
  { id: 639, name: "Bharathi TV Madurai", url: "https://stream.onecloudlive.in/karnan/bharathitv/index.m3u8", working: false },
  { id: 640, name: "BMS TV", url: "https://rtmp.bmlive.net/bms/bms/index.m3u8", working: false },
  { id: 641, name: "Boobsh TV", url: "https://rtmp.applelive.in/boobsh/boobsh/index.m3u8", working: false },
  { id: 642, name: "BSC Old", url: "https://stream.onecloudlive.in/bschd/live/index.m3u8", working: false },
  { id: 643, name: "C TV", url: "http://ctv.phoenixcreations.online:1935/ctv/ctv/playlist.m3u8", working: false },
  { id: 644, name: "Channel Spice", url: "https://stream.onecloudlive.in/spicetv/spicetv/index.m3u8", working: false },
  { id: 645, name: "Crayonz", url: "https://rtmp.bmlive.net/stream/crayonz/index.m3u8", working: false },
  { id: 646, name: "CSK TV", url: "http://csktv.7starcloud.com:1935/csktv/csktvdpi/playlist.m3u8", working: false },
  { id: 647, name: "CTN Channel", url: "https://live.olidigital.in/ctnchannel/ctnchannel/index.m3u8", working: false },
  { id: 648, name: "D Jeyam", url: "https://stream.singamcloud.in/djeyam/djeyam/index.m3u8", working: false },
  { id: 649, name: "Deavathai TV", url: "https://hdbox.singamcloud.in/Deavathaitv/Deavathaitv/index.m3u8", working: false },
  { id: 650, name: "Deebam TV", url: "https://play.applelive.in/deebamtv/deebamtv.m3u8", working: false },
  { id: 651, name: "Devasena TV", url: "http://stream.onecloudlive.in/sachintv/devasenatvhd/index.m3u8", working: false },
  { id: 652, name: "Devasena TV", url: "http://stream.onecloudlive.in/sachintv/devasenatvhd/index.m3u8", working: false },
  { id: 653, name: "Dharani TV", url: "http://dharnitv.phoenixcreations.online/dharnitv/dharni/playlist.m3u8", working: false },
  { id: 654, name: "Dharsan TV [Tata Play]", url: "https://cable91tataplay.akamaized.net/live/dharshantv/index.m3u8", working: false },
  { id: 655, name: "Dhoni TV", url: "https://ipcloud.live/sachintv/dhonitv/index.m3u8", working: false },
  { id: 656, name: "Dinesh PT", url: "http://198.144.149.206:8080/DINESH/PT/index.m3u8?token=YAAL", working: false },
  { id: 657, name: "DSR Channel", url: "https://ipcloud.live/dsrchannel/dsrhd/index.m3u8", working: false },
  { id: 658, name: "DSR HD", url: "http://ipcloud.live/dsrchannel/dsrhd/index.m3u8", working: false },
  { id: 659, name: "Durai TV", url: "https://ipcloud.live/duraitv/live/index.m3u8", working: false },
  { id: 660, name: "Eason TV", url: "https://amigofx.com:1936/easontv/easontv/playlist.m3u8", working: false },
  { id: 661, name: "Emperor TV", url: "https://rtmp.bmlive.net/bms/emperortv/stream.m3u8", working: false },
  { id: 662, name: "Fox TV", url: "https://stream.onecloudlive.in/foxtv/foxtv/index.m3u8", working: false },
  { id: 663, name: "G Music", url: "https://rtmp.applelive.in/gmusic/gmusic/index.m3u8", working: false },
  { id: 664, name: "Ganesh TV Live", url: "https://live.thendralcloud.in/ganeshtvlive/d0dbe915091d400bd8ee7f27f0791303.sdp/playlist.m3u8", working: false },
  { id: 665, name: "Global TV", url: "https://play.applelive.in/globaltv/globaltv.m3u8", working: false },
  { id: 666, name: "Gold 24", url: "http://gold24.phoenixcreations.online/gold24/gold24/index.m3u8", working: false },
  { id: 667, name: "Gold 24 TV", url: "http://gold24.phoenixcreations.online/gold24/gold24/index.m3u8", working: false },
  { id: 668, name: "GSJK TV", url: "https://live.brightmeltech.in/gsjktv/gsjktv.m3u8", working: false },
  { id: 669, name: "Hai TV", url: "https://play.applelive.in/haitv/haitv.m3u8", working: false },
  { id: 670, name: "Hai TV 2", url: "http://applelive.in/haitv/haitv.m3u8", working: false },
  { id: 671, name: "Heartbeat TV", url: "https://rtmp.bmlive.net/bms/heartbeattv/stream.m3u8", working: false },
  { id: 672, name: "Holy Land TV", url: "https://play.applelive.in/holylandtv/holylandtv.m3u8", working: false },
  { id: 673, name: "Imai TV", url: "https://live20.bozztv.com/akamaissh101/ssh101/imaitv/playlist.m3u8", working: false },
  { id: 674, name: "Isai HD", url: "https://server.sscloud7.in/isaihd/isaihd/index.m3u8", working: false },
  { id: 675, name: "IWorld TV", url: "https://view.apserver.in/tmp_hls10/iworldtv/index.m3u8", working: false },
  { id: 676, name: "J King TV", url: "https://live.brightmeltech.in/jkingtv/jkingtv.m3u8", working: false },
  { id: 677, name: "Jayam TV Karur", url: "https://view.rcserver.in/tmp_hls10/jayamtvkarur/index.m3u8", working: false },
  { id: 678, name: "Jayam TV Polur", url: "https://live.singamcloud.in/jayamtv/jayamki/index.m3u8", working: false },
  { id: 679, name: "Jesus Alive TV", url: "https://play.applelive.in/jesusalivetv/jesusalivetv.m3u8", working: false },
  { id: 680, name: "Jeyasubbu TV HD", url: "https://view.rcserver.in/tmp_hls15/jeyasubbumovies/index.m3u8", working: false },
  { id: 681, name: "JJ News Tamil", url: "https://live.skystream.in/live/jjnewstamil/index.m3u8?hls_ctx=141308l7", working: false },
  { id: 682, name: "JJ News Tamil", url: "https://live.skystream.in/live/jjnewstamil/index.m3u8", working: false },
  { id: 683, name: "JP Music TV", url: "https://stream.onecloudlive.in/sachintv/jpmusichd/index.m3u8", working: false },
  { id: 684, name: "JR Malar TV", url: "https://server.sscloud7.in/live/malartv/index.m3u8", working: false },
  { id: 685, name: "JRP TV Bala", url: "https://ipcloud.live/jrptv/bala/index.m3u8", working: false },
  { id: 686, name: "JTK TV", url: "http://jtktv.indiamatrix.in/jtktvkay/jtktvkay.m3u8", working: false },
  { id: 687, name: "JTK TV", url: "http://jtktv.indiamatrix.in/jtktvkay/jtktvkay.m3u8", working: false },
  { id: 688, name: "K Channel", url: "http://brightmeltech.in/kchannel/kchannel.m3u8", working: false },
  { id: 689, name: "K Channel", url: "https://live.brightmeltech.in/kchannel/kchannel.m3u8", working: false },
  { id: 690, name: "Kallai TV", url: "https://stream.onecloudlive.in/kallaiads/kallaitv/index.m3u8", working: false },
  { id: 691, name: "Kanchi TV", url: "http://198.144.149.206:8080/NOTV/KANCHITV/index.m3u8?token=GTR", working: false },
  { id: 692, name: "Kanchi TV", url: "http://198.144.149.206:8080/NOTV/KANCHITV/index.m3u8?token=GTR", working: false },
  { id: 693, name: "Karthick TV", url: "https://ipcloud.live/karthick/karthicktvhd/index.m3u8", working: false },
  { id: 694, name: "Kathir TV", url: "https://stream.ashokadigital.net/kathirtv/kathirtv/index.m3u8", working: false },
  { id: 695, name: "KCTN TV", url: "http://ttv.7starcloud.com:1935/kctn/tv/playlist.m3u8", working: false },
  { id: 696, name: "KCTN TV", url: "http://ttv.7starcloud.com:1935/kctn/tv/playlist.m3u8", working: false },
  { id: 697, name: "King TV 2", url: "http://kingtv.sscloud7.in/kingtv/kingtv/index.m3u8", working: false },
  { id: 698, name: "King TV Alangulam", url: "https://server.sscloud7.in/kingtv/kingtv/index.m3u8", working: false },
  { id: 699, name: "Kirubai Goodnews TV", url: "http://kirubaitv.phoenixcreations.online/kirubaitv/kirubaitv/index.m3u8", working: false },
  { id: 700, name: "Kirubai Goodnews TV", url: "http://kirubaitv.phoenixcreations.online/kirubaitv/kirubaitv/index.m3u8", working: false },
  { id: 701, name: "KK TV", url: "https://web.applelive.in/stream/kktv/index.m3u8", working: false },
  { id: 702, name: "KM Music", url: "https://live.sscloud7.in/kmmusic/kmmusic/index.m3u8", working: false },
  { id: 703, name: "Koodal TV", url: "https://web.applelive.in/koodaltv/koodaltv/index.m3u8", working: false },
  { id: 704, name: "Leo TV HD", url: "https://ipcloud.live/leotv/leotvhd/index.m3u8", working: false },
  { id: 705, name: "Love Joy TV", url: "https://ipcloud.live/novamani/lovejoytv/index.m3u8", working: false },
  { id: 706, name: "Malathi TV", url: "https://ipcloud.live/malathitv/malathitv/index.m3u8", working: false },
  { id: 707, name: "Mallai TV", url: "https://rojatv.cloud/mallaitv/mallaitv/index.m3u8", working: false },
  { id: 708, name: "Malligai TV", url: "https://server.sscloud7.in/live/malligai/index.m3u8", working: false },
  { id: 709, name: "Manju TV", url: "https://stream.onecloudlive.in/manjutv/manjutv/index.m3u8", working: false },
  { id: 710, name: "Mathan TV 3", url: "https://ipcloud.live/mathantv/mathantv/index.m3u8", working: false },
  { id: 711, name: "Max Movies", url: "https://live.maxtn.in/maxmovies/maxmovies/index.m3u8", working: false },
  { id: 712, name: "Max Music", url: "https://live.maxtn.in/maxmusic/maxmusic/index.m3u8", working: false },
  { id: 713, name: "Max TV Tenkasi", url: "https://stream.onecloudlive.in/maxtv/maxtvtenkasi/index.m3u8", working: false },
  { id: 714, name: "ME24 Tamil", url: "https://stream.onecloudlive.in/orange/ME24TAMIL/index.m3u8", working: false },
  { id: 715, name: "MM TV", url: "https://stream.iplive.xyz/mmtvtc/mmtvhd/index.m3u8", working: false },
  { id: 716, name: "MM TV Valliyur", url: "http://mmtv.phoenixcreations.online/mmtv/mm/index.m3u8", working: false },
  { id: 717, name: "MM TV Valliyur", url: "http://mmtv.phoenixcreations.online/mmtv/mm/index.m3u8", working: false },
  { id: 718, name: "MN Music", url: "https://mntv.livebox.co.in/musichls/live.m3u8", working: false },
  { id: 719, name: "MP TV", url: "https://stream.sscloud7.in/live/mptv/index.m3u8", working: false },
  { id: 720, name: "MTV Men HD", url: "https://ipcloud.live/mtv/menhd/index.m3u8", working: false },
  { id: 721, name: "MTV Trichy", url: "https://stream.iplive.xyz/mtv/mtvhd/index.m3u8", working: false },
  { id: 722, name: "MTV Virudhunagar", url: "https://stream.ashokadigital.net/mtvlive/mtvlive/index.m3u8", working: false },
  { id: 723, name: "Mullai TV", url: "https://ipcloud.live/mullaitv/mullaitv/index.m3u8", working: false },
  { id: 724, name: "News 80", url: "http://198.144.149.206:8080/NOTV/NEWS80/index.m3u8?token=GTR", working: false },
  { id: 725, name: "News 80 Tamil", url: "http://198.144.149.206:8080/NOTV/NEWS80/index.m3u8?token=GTR", working: false },
  { id: 726, name: "Nila TV", url: "https://stream.onecloudlive.in/nilaatv/nilahd/index.m3u8", working: false },
  { id: 727, name: "Nila TV Nellai", url: "https://stream.onecloudlive.in/nilatvkutti/nilatvhd/index.m3u8", working: false },
  { id: 728, name: "Nila TV Sivaganga", url: "https://ipcloud.live/nilatvsvg/nilatv/index.m3u8", working: false },
  { id: 729, name: "No 1 TV", url: "https://live.skystream.in/live/no1tv/index.m3u8", working: false },
  { id: 730, name: "NTC TV [Tata Play]", url: "https://cable85tataplay.akamaized.net/live/ntvpkt/index.m3u8", working: false },
  { id: 731, name: "Om Sakthi TV", url: "https://live1.sscloud7.com/live/omsakthitv/index.m3u8", working: false },
  { id: 732, name: "One Hollywood", url: "https://stream.rojatv.cloud/one/hollywood/index.m3u8", working: false },
  { id: 733, name: "One Movies", url: "https://stream.rojatv.cloud/one/movies/index.m3u8", working: false },
  { id: 734, name: "Paasamalar TV", url: "https://stream.sscloud7.in/live/paasamalartv/index.m3u8", working: false },
  { id: 735, name: "Paavai TV", url: "https://ipcloud.live/paavai/live/index.m3u8", working: false },
  { id: 736, name: "Palkar TV", url: "https://live.applelive.in/palkartv/palkartv/index.m3u8", working: false },
  { id: 737, name: "PCN TV", url: "https://rtmp.bmlive.net/bms/pcn/stream.m3u8", working: false },
  { id: 738, name: "PCV Channel", url: "https://stream.sscloud7.in/live/livepcv/index.m3u8", working: false },
  { id: 739, name: "Pon TV", url: "http://pontv.phoenixcreations.online/pontv/pon/index.m3u8", working: false },
  { id: 740, name: "Pon TV", url: "http://pontv.phoenixcreations.online/pontv/pon/index.m3u8", working: false },
  { id: 741, name: "Pothigai Thendral", url: "https://ipcloud.live/pothigai/thendral/index.m3u8", working: false },
  { id: 742, name: "R TV", url: "https://ipcloud.live/rtv/rtvstream/index.m3u8", working: false },
  { id: 743, name: "Rainbow TV", url: "https://live.skystream.in/live/rainbowtv/index.m3u8?hls_ctx=a7618r13", working: false },
  { id: 744, name: "Rainbow TV Gandarvakottai", url: "https://notvstream.in/rainbowtv/rainbowtv/index.m3u8", working: false },
  { id: 745, name: "Raja TV", url: "http://live.brightmeltech.in/rajatv/rajatv.m3u8", working: false },
  { id: 746, name: "Raja TV", url: "https://live.brightmeltech.in/rajatv/rajatv.m3u8", working: false },
  { id: 747, name: "Ramya TV", url: "https://live.brightmeltech.in/ramyatv/ramyatv.m3u8", working: false },
  { id: 748, name: "Rasi Cinema", url: "https://rasinetworks.in/live/rasicinemahd/index.m3u8", working: false },
  { id: 749, name: "Rasi Cinemax", url: "https://rasinetworks.in/live/rasicinemaxhd/index.m3u8", working: false },
  { id: 750, name: "Rasi Classic", url: "https://rasinetworks.in/live/rasiclassichd/index.m3u8", working: false },
  { id: 751, name: "Rasi Comedy", url: "https://rasinetworks.in/live/rasicomedyhd/index.m3u8", working: false },
  { id: 752, name: "Rasi Hollywood", url: "https://rasinetworks.in/live/rasihollywoodhd/index.m3u8", working: false },
  { id: 753, name: "Rasi Lifestyle", url: "https://rasinetworks.in/live/rasilifestylehd/index.m3u8", working: false },
  { id: 754, name: "Rasi Movies", url: "https://rasinetworks.in/live/rasimovieshd/index.m3u8", working: false },
  { id: 755, name: "Rasi Music", url: "https://rasinetworks.in/live/rasimusichd/index.m3u8", working: false },
  { id: 756, name: "Rasi Tamil", url: "https://rasinetworks.in/live/rasitamilhd/index.m3u8", working: false },
  { id: 757, name: "Rasi TV", url: "https://rasinetworks.in/live/rasitvhd/index.m3u8", working: false },
  { id: 758, name: "RC Television", url: "https://view.rcserver.in/tmp_hls1/stream/index.m3u8", working: false },
  { id: 759, name: "Right TV", url: "https://stream.onecloudlive.in/righttv/live/index.m3u8", working: false },
  { id: 760, name: "Riya TV", url: "https://play.applelive.in/riyatv/riyatv.m3u8", working: false },
  { id: 761, name: "Riya TV 2", url: "http://applelive.in/riyatv/riyatv.m3u8", working: false },
  { id: 762, name: "RJ Tamil TV", url: "https://ipcloud.live/rjtamiltv/rjtamil/index.m3u8", working: false },
  { id: 763, name: "Robo TV", url: "https://play.applelive.in/robotv/robotv.m3u8", working: false },
  { id: 764, name: "Rowthiram TV", url: "https://live3.onecloudlive.in/eleventv/eleventv/index.m3u8", working: false },
  { id: 765, name: "RR TV", url: "https://notvstream.in/rrtv/rrtv/index.m3u8", working: false },
  { id: 766, name: "RTV", url: "https://stream.ashokadigital.net/rtv/rtv/index.m3u8", working: false },
  { id: 767, name: "RV Tamil", url: "https://ipcloud.live/rvtv/rvtvhd/index.m3u8", working: false },
  { id: 768, name: "Saami TV", url: "https://ipcloud.live/msntv/saamitv/index.m3u8", working: false },
  { id: 769, name: "Sachin TV", url: "https://ipcloud.live/sachintv/sachintvhd/index.m3u8", working: false },
  { id: 770, name: "Sai TV Madurai", url: "https://stream.onecloudlive.in/saitvmdu/saitvmdu/index.m3u8", working: false },
  { id: 771, name: "Salam TV HD", url: "https://stream.onecloudlive.in/salamtv/salamtvhd/index.m3u8", working: false },
  { id: 772, name: "Sana Plus [Tata Play]", url: "https://cable74tataplay.akamaized.net/hls/sanaplus.m3u8", working: false },
  { id: 773, name: "Sana TV [Tata Play]", url: "https://cable75tataplay.akamaized.net/hls/sanatv.m3u8", working: false },
  { id: 774, name: "Sangamam TV Erode", url: "https://stream.onecloudlive.in/sangamamtv/sangamamtvhd/index.m3u8", working: false },
  { id: 775, name: "Sangamam TV HD", url: "https://stream.onecloudlive.in/sangamamtv/sangamamtvhd/index.m3u8", working: false },
  { id: 776, name: "SAR TV Tenkasi", url: "http://sartv2.phoenixcreations.online:1935/sartv2/sartv2/playlist.m3u8", working: false },
  { id: 777, name: "Senthamil TV", url: "https://view.rcserver.in/tmp_hls16/senthamiltv/index.m3u8", working: false },
  { id: 778, name: "Shalwin TV", url: "https://live3.onecloudlive.in/shalwintv/shalwintv/index.m3u8", working: false },
  { id: 779, name: "Shammah TV", url: "https://play.applelive.in/shammahtv/shammahtv.m3u8", working: false },
  { id: 780, name: "Sharon TV", url: "https://sscloud7.com/live/sharontv/index.m3u8", working: false },
  { id: 781, name: "Sharon TV 2", url: "https://rtmp.bmlive.net/bms/sharontv/index.m3u8", working: false },
  { id: 782, name: "Siddhar TV", url: "http://198.144.149.206:8080/DINESH/PT2/index.m3u8?token=YAAL", working: false },
  { id: 783, name: "Siddhar TV", url: "http://198.144.149.206:8080/DINESH/PT2/index.m3u8?token=YAAL", working: false },
  { id: 784, name: "Singam TV", url: "https://live.brightmeltech.in/singamtv/singamtv.m3u8", working: false },
  { id: 785, name: "Siva TV", url: "https://app.xstream.onecloudlive.in/sivatv/sivatv/index.m3u8", working: false },
  { id: 786, name: "Siva TV", url: "http://xstream.onecloudlive.in:8080/sivatv/sivatv/index.m3u8", working: false },
  { id: 787, name: "SK Media", url: "https://rtmp.bmlive.net/stream/skmedia/index.m3u8", working: false },
  { id: 788, name: "Sky TV", url: "http://198.144.149.206:8080/NOTV/SKYTV/index.m3u8?token=GTR", working: false },
  { id: 789, name: "Sky TV", url: "http://198.144.149.206:8080/NOTV/SKYTV/index.m3u8?token=GTR", working: false },
  { id: 790, name: "Smiley TV", url: "https://live1.sscloud7.com/live/smileytv/index.m3u8", working: false },
  { id: 791, name: "SNR TV", url: "http://198.144.149.206:8080/NOTV/ASOSACHENNAI/index.m3u8?token=GTR", working: false },
  { id: 792, name: "Solai TV", url: "https://ipcloud.live/solaitv/solaihd/index.m3u8", working: false },
  { id: 793, name: "Sri Kanchi", url: "https://live.maxtn.in/srikanchi/kanchi/index.m3u8", working: false },
  { id: 794, name: "Sri Krishna TV", url: "http://krishnatv.7starcloud.com:1935/erodekrishnatv/livestream/playlist.m3u8", working: false },
  { id: 795, name: "Sri Krishna TV Tiruchengode", url: "http://krishnatv.7starcloud.com:1935/live/livestream/playlist.m3u8", working: false },
  { id: 796, name: "Sri Krishna TV Tiruchengode", url: "http://krishnatv.7starcloud.com:1935/live/livestream/playlist.m3u8", working: false },
  { id: 797, name: "Sri Velavan TV", url: "https://rtmp.applelive.in/srivelavantvultrahd/srivelavantvultrahd/index.m3u8", working: false },
  { id: 798, name: "SS TV", url: "http://rajatv.phoenixcreations.online/sstv/sstv/playlist.m3u8", working: false },
  { id: 799, name: "SSS HD", url: "http://103.78.164.62:8090/SSSHD/index.m3u8", working: false },
  { id: 800, name: "SSS TV", url: "http://103.78.164.62:8090/SSSHD/index.m3u8", working: false },
  { id: 801, name: "Strawberry TV", url: "https://stream.onecloudlive.in/sachintv/strawberrytv/index.m3u8", working: false },
  { id: 802, name: "Stream HLS", url: "https://view.rcserver.in/tmp_hls2/stream/index.m3u8", working: false },
  { id: 803, name: "Subash TV", url: "https://ipcloud.live/subashtv/subashhd/index.m3u8", working: false },
  { id: 804, name: "Subin TV [Tata Play]", url: "https://cable88tataplay.akamaized.net/live/subintv/index.m3u8", working: false },
  { id: 805, name: "Surya TV", url: "http://suryatv.phoenixcreations.online/suryatv/surya/index.m3u8", working: false },
  { id: 806, name: "Surya TV", url: "http://suryatv.phoenixcreations.online/suryatv/surya/index.m3u8", working: false },
  { id: 807, name: "Surya TV Digital", url: "https://live.sscloud7.in/live/suryatv/index.m3u8", working: false },
  { id: 808, name: "Taital TV", url: "https://stream.onecloudlive.in/taitaltv/live/index.m3u8", working: false },
  { id: 809, name: "Tamil Oli TV", url: "https://view.rcserver.in/tmp_hls7/tamilolitv/index.m3u8", working: false },
  { id: 810, name: "Tamil TV", url: "https://stream.onecloudlive.in/tamiltv/tamiltvhd/index.m3u8", working: false },
  { id: 811, name: "Temble TV", url: "https://notvstream.in/tembletv/tembletv/index.m3u8", working: false },
  { id: 812, name: "Thalapathy TV", url: "https://play.applelive.in/thalapathytv/thalapathytv.m3u8", working: false },
  { id: 813, name: "Tharani TV", url: "https://singamcloud.in/tharanitvtvl/tharanitvtvl/index.m3u8", working: false },
  { id: 814, name: "Thendral TV Madurai", url: "https://ipcloud.live/thendralmdu/madurai/index.m3u8", working: false },
  { id: 815, name: "Thirumagal TV", url: "http://ttv.7starcloud.com:1935/thirumagal/tv/playlist.m3u8", working: false },
  { id: 816, name: "Thirumagal TV", url: "http://ttv.7starcloud.com:1935/thirumagal/tv/playlist.m3u8", working: false },
  { id: 817, name: "Thirumalai TV", url: "https://stream.onecloudlive.in/mullaitvhd/thirumalai/index.m3u8", working: false },
  { id: 818, name: "Thirumalai TV Madurai", url: "https://ipcloud.live/thirumalaitv/madurai/index.m3u8", working: false },
  { id: 819, name: "Thogai TV", url: "https://saran.phoenixcreations.online/thogaitv/thogaitv/playlist.m3u8", working: false },
  { id: 820, name: "Thulir TV", url: "https://view.apserver.in/tmp_hls3/thulirtv/index.m3u8", working: false },
  { id: 821, name: "Top TV Thuraiyur (2.5 min catchup)", url: "https://stream.rojatv.cloud/TOPTV/onecloud/index.m3u8", working: false },
  { id: 822, name: "TSN Hollywood Tamil", url: "http://198.144.149.206:8080/DINESH/PT/index.m3u8?token=YAAL", working: false },
  { id: 823, name: "TSN Music", url: "http://198.144.149.206:8080/NOTV/VAAGAI/index.m3u8?token=GTR", working: false },
  { id: 824, name: "Udhayam TV", url: "https://ipcloud.live/udhayamtv/udhayamtv/index.m3u8", working: false },
  { id: 825, name: "Ultimate TV [Tata Play]", url: "https://cable92tataplay.akamaized.net/live/utv/index.m3u8", working: false },
  { id: 826, name: "V Muziq", url: "https://app.ashokadigital.net/vmusic/vmusic/index.m3u8", working: false },
  { id: 827, name: "V TV", url: "https://live.applelive.in/vtv/vtv/index.m3u8", working: false },
  { id: 828, name: "Vaagai TV", url: "http://198.144.149.206:8080/NOTV/VAAGAI/index.m3u8?token=GTR", working: false },
  { id: 829, name: "Vajra TV (TACTV)", url: "http://iptv7.iptv.pics/hls/vajira_src/index.m3u8", working: false },
  { id: 830, name: "Vanavil TV", url: "http://ttv.7starcloud.com:1935/vaanavil/tv/playlist.m3u8", working: false },
  { id: 831, name: "Vanavil TV", url: "http://ttv.7starcloud.com:1935/vaanavil/tv/playlist.m3u8", working: false },
  { id: 832, name: "Vasantham TV", url: "https://stream.onecloudlive.in/dhandapani/vasanthamtv/index.m3u8", working: false },
  { id: 833, name: "VCTN TV", url: "http://ttv.7starcloud.com:1935/vctn/tv/playlist.m3u8", working: false },
  { id: 834, name: "VCTN TV", url: "http://ttv.7starcloud.com:1935/vctn/tv/playlist.m3u8", working: false },
  { id: 835, name: "Velan TV", url: "https://cloudstream4k.com/velantv/bsk/index.m3u8", working: false },
  { id: 836, name: "Velur TV", url: "https://stream.onecloudlive.in/bass/velurtv/index.m3u8", working: false },
  { id: 837, name: "VIP TV", url: "https://ipcloud.live/vip/viptv/index.m3u8", working: false },
  { id: 838, name: "Vishil TV", url: "https://stream.sscloud7.in/live/vishiltv1/index.m3u8", working: false },
  { id: 839, name: "Vision TV", url: "https://rtmp.bmlive.net/bms/visiontv/index.m3u8", working: false },
  { id: 840, name: "Web World Stream", url: "https://server1.thewebworld.in:3797/stream/play.m3u8", working: false },
  { id: 841, name: "Yatra TV", url: "https://live.rojatv.cloud/yatra/tv/index.m3u8", working: false },
  { id: 842, name: "Yogaa TV", url: "https://ipcloud.live/yogaatv/yogaatv/index.m3u8", working: false }
];

function InteractivePlayer({ channel }: { channel: typeof channels[number] }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let hls: Hls | null = null;
    setError(null);
    const video = videoRef.current;

    if (!video) return;

    if (Hls.isSupported()) {
      hls = new Hls({
        startLevel: -1,
        capLevelToPlayerSize: true, // Prevents loading 4K profiles on small displays
        enableWorker: true,
        lowLatencyMode: false,
        backBufferLength: 90,
        maxBufferLength: 120, // Huge buffer to prevent stuttering
        maxMaxBufferLength: 600, // Maximum allowed buffer
        maxBufferSize: 60 * 1000 * 1000, // Increased buffer size limit
        manifestLoadingTimeOut: 20000,
        manifestLoadingMaxRetry: 5,
        levelLoadingTimeOut: 20000,
        levelLoadingMaxRetry: 5,
        fragLoadingTimeOut: 20000,
        fragLoadingMaxRetry: 5,
        appendErrorMaxRetry: 5,
        xhrSetup: function(xhr, url) {
            xhr.withCredentials = true;
        }
      });

      const proxyUrl = `/api/proxy?url=${encodeURIComponent(channel.url)}`;
      hls.loadSource(proxyUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, function () {
        video.play().catch(e => {
          if (e.name !== 'AbortError') {
            console.warn("Autoplay blocked:", e);
          }
        });
      });

      hls.on(Hls.Events.ERROR, function (event, data) {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              console.warn("Fatal network error encountered, trying to recover");
              hls?.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              console.warn("Fatal media error encountered, trying to recover");
              hls?.recoverMediaError();
              break;
            default:
              console.error("Fatal error, cannot recover", data);
              setError("Stream is currently offline or unavailable.");
              hls?.destroy();
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native HLS support (Safari)
      const proxyUrl = `/api/proxy?url=${encodeURIComponent(channel.url)}`;
      video.src = proxyUrl;
      video.addEventListener('loadedmetadata', function () {
        video.play().catch(e => {
          if (e.name !== 'AbortError') {
            console.warn("Autoplay blocked:", e);
          }
        });
      });
      video.addEventListener('error', function() {
        setError("Stream is currently offline or unavailable.");
      })
    }

    return () => {
      if (hls) {
        hls.destroy();
      }
      video.removeAttribute('src'); // Stop downloading
      video.load();
    };
  }, [channel]);

  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden z-[1]">
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-fill z-[1] bg-black"
        controls={false}
        autoPlay
        playsInline
      />

      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#05070a]/90 text-white z-[5] p-8 text-center gap-4 backdrop-blur-sm">
          <AlertCircle className="w-12 h-12 text-[#007aff]" />
          <p className="text-xl font-medium tracking-wide">{error}</p>
          <p className="text-sm opacity-60 font-mono">Trying to load: {channel.name}</p>
        </div>
      )}
    </div>
  );
}

export function Clock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const timeString = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const dateString = time.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });

  return (
    <div className="flex flex-col items-end">
      <div className="text-3xl font-bold tracking-wider drop-shadow-md">
        {timeString}
      </div>
      <div className="text-sm tracking-[0.2em] uppercase font-bold text-white/50 mt-1">
        {dateString}
      </div>
    </div>
  );
}

export default function App() {
  const [activeChannelIndex, setActiveChannelIndex] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedSidebarIndex, setSelectedSidebarIndex] = useState(0);
  const [typedNumber, setTypedNumber] = useState<string>("");
  const [showChannelInfo, setShowChannelInfo] = useState(true);
  const listRef = useRef<HTMLUListElement>(null);

  // Hide channel info after 2 seconds
  useEffect(() => {
    setShowChannelInfo(true);
    const timeout = setTimeout(() => {
      setShowChannelInfo(false);
    }, 2000);
    return () => clearTimeout(timeout);
  }, [activeChannelIndex]);

  // Scroll active sidebar item into view
  useEffect(() => {
    if (isSidebarOpen) {
      const activeItem = document.getElementById(`channel-item-${selectedSidebarIndex}`);
      if (activeItem) {
        activeItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [selectedSidebarIndex, isSidebarOpen]);

  // Handle Typed numbers timeout
  useEffect(() => {
    if (typedNumber) {
      const timeout = setTimeout(() => {
        const num = parseInt(typedNumber, 10);
        if (num >= 1 && num <= channels.length) {
          setActiveChannelIndex(num - 1);
          setIsSidebarOpen(false);
        } else {
          // If invalid number, just visually feedback or ignore
        }
        setTypedNumber(""); 
      }, 2000);
      return () => clearTimeout(timeout);
    }
  }, [typedNumber]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Attempt to resume video on any keypress to combat autoplay blockers
      const video = document.querySelector('video');
      if (video && video.paused) {
        video.play().catch(() => {});
      }

      // Prevent default scrolling for up/down
      if (['ArrowUp', 'ArrowDown', 'Space', 'Enter'].includes(e.key)) {
        e.preventDefault();
      }

      // 1. Handle Numbers typing
      if (/^[0-9]$/.test(e.key)) {
        setTypedNumber(prev => {
          let newStr = prev + e.key;
          // limit to at most 3 digits since max is 50
          if (newStr.length > 3) newStr = newStr.slice(1);
          return newStr;
        });
        return;
      }

      // 2. Handle Enter / OK
      // Standard Enter or NumpadEnter or generic selection from TV remotes
      if (e.key === 'Enter' || e.code === 'Enter' || e.key === 'Select' || e.keyCode === 13 || e.keyCode === 23) {
        if (typedNumber) {
          const num = parseInt(typedNumber, 10);
          if (num >= 1 && num <= channels.length) {
            setActiveChannelIndex(num - 1);
            setIsSidebarOpen(false);
          }
          setTypedNumber("");
        } else if (isSidebarOpen) {
          // Confirm channel from sidebar
          setActiveChannelIndex(selectedSidebarIndex);
          setIsSidebarOpen(false);
        } else {
          // Open sidebar
          setIsSidebarOpen(true);
          setSelectedSidebarIndex(activeChannelIndex);
        }
        return;
      }

      // 3. Close with Back/Esc
      if (e.key === 'Escape' || e.key === 'Backspace' || e.key === 'GoBack' || e.keyCode === 27) {
        if (isSidebarOpen) {
          setIsSidebarOpen(false);
          return;
        }
      }

      // 4. Directional navigation
      if (isSidebarOpen) {
        if (e.key === 'ArrowUp' || e.keyCode === 38) {
          setSelectedSidebarIndex(prev => (prev > 0 ? prev - 1 : channels.length - 1));
        } else if (e.key === 'ArrowDown' || e.keyCode === 40) {
          setSelectedSidebarIndex(prev => (prev < channels.length - 1 ? prev + 1 : 0));
        } else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft' || e.keyCode === 37 || e.keyCode === 39) {
          setIsSidebarOpen(false);
        }
      } else {
        // Direct channel changing using Arrows, +, -, PageUp, PageDown
        if (
          e.key === 'ArrowUp' || e.keyCode === 38 ||
          e.key === 'ChannelUp' || e.keyCode === 427 ||
          e.key === '+' || e.key === '=' ||
          e.key === 'PageUp' || e.keyCode === 33 ||
          e.key === 'MediaTrackNext'
        ) {
          setActiveChannelIndex(prev => (prev < channels.length - 1 ? prev + 1 : 0));
        } else if (
          e.key === 'ArrowDown' || e.keyCode === 40 ||
          e.key === 'ChannelDown' || e.keyCode === 428 ||
          e.key === '-' || e.key === '_' ||
          e.key === 'PageDown' || e.keyCode === 34 ||
          e.key === 'MediaTrackPrevious'
        ) {
          setActiveChannelIndex(prev => (prev > 0 ? prev - 1 : channels.length - 1));
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSidebarOpen, activeChannelIndex, selectedSidebarIndex, typedNumber]);

  const currentChannel = channels[activeChannelIndex];

  return (
    <div 
      className="flex w-full h-screen bg-[#05070a] text-white relative font-sans overflow-hidden"
      onClick={() => {
        if (!isSidebarOpen && !typedNumber) {
          setIsSidebarOpen(true);
          setSelectedSidebarIndex(activeChannelIndex);
        }
        // Attempt to resume playback if stuck
        const video = document.querySelector('video');
        if (video && video.paused) {
          video.play().catch(() => {});
        }
      }}
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#1a1c24_0%,#05070a_100%)] z-0 pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(0,0,0,0.8)_0%,transparent_40%,transparent_60%,rgba(0,0,0,0.8)_100%)] z-[2] pointer-events-none" />
      
      {/* Video Player Background */}
      <InteractivePlayer channel={currentChannel} />

      {/* Top Elements */}
      <div className={cn(
        "absolute top-10 z-[5] flex justify-between w-full pr-10 items-start pointer-events-none transition-all duration-300",
        isSidebarOpen ? "left-[360px] max-w-[calc(100%-360px)]" : "left-10 max-w-[calc(100%-40px)]"
      )}>
        <AnimatePresence>
          {showChannelInfo && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="flex gap-4"
            >
              <div className="px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-xs font-bold tracking-wide">TAMIL</div>
              <div className="px-4 py-2 rounded-full bg-[#007aff] text-xs font-bold tracking-wide shadow-[0_0_15px_rgba(0,122,255,0.4)]">ENTERTAINMENT</div>
            </motion.div>
          )}
        </AnimatePresence>
        
        <Clock />
      </div>

      {/* Info Overlay (Fades out when not changing channels/opening menus) */}
      <AnimatePresence>
        {showChannelInfo && (
          <motion.div 
            key={currentChannel.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="absolute top-36 right-10 z-[5] text-right pointer-events-none flex flex-col items-end"
          >
            <div className="text-[120px] font-extrabold leading-[0.8] opacity-90 drop-shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
              {currentChannel.id.toString().padStart(2, '0')}
            </div>
            <div className="text-2xl font-light mt-2.5 text-[#007aff] uppercase tracking-[2px]">
              {currentChannel.name}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dynamic Bottom HUD */}
      <AnimatePresence>
        {showChannelInfo && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.4 }}
            className={cn(
              "absolute bottom-0 left-0 right-0 h-[120px] bg-gradient-to-t from-black/90 to-transparent z-[5] px-10 flex items-center justify-between pointer-events-none transition-all duration-300",
              isSidebarOpen ? "pl-[360px]" : "pl-10"
            )}
          >
            <div className="flex-1 pr-20">
              <div className="flex justify-between items-end mb-1">
                <span className="text-lg font-semibold tracking-wide">Live Broadcast</span>
                <span className="text-xs opacity-60 font-mono">--:-- / --:--</span>
              </div>
              <div className="h-1 bg-white/20 rounded-full w-full mt-2.5 relative overflow-hidden">
                <div className="h-full w-[35%] bg-[#007aff] rounded-full shadow-[0_0_10px_#007aff]" />
              </div>
            </div>
            <div className="flex gap-5 text-xs uppercase tracking-[1px] opacity-60">
              <div><span className="bg-white/15 px-2 py-1 rounded text-white mr-1.5 font-semibold">OK</span> List</div>
              <div><span className="bg-white/15 px-2 py-1 rounded text-white mr-1.5 font-semibold">CH +/-</span> Change</div>
              <div><span className="bg-white/15 px-2 py-1 rounded text-white mr-1.5 font-semibold">0-9</span> Number</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Typed Number Indicator */}
      <AnimatePresence>
        {typedNumber && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 pointer-events-none"
          >
            <div className="bg-[#0a0c11]/80 backdrop-blur-[20px] px-12 py-8 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-center justify-center border border-white/10">
              <span className="text-8xl font-black tracking-widest text-[#007aff] drop-shadow-[0_0_20px_rgba(0,122,255,0.5)] flex items-center gap-2">
                <Hash className="w-16 h-16 opacity-50" />
                {typedNumber}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* TV Guide Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="absolute inset-0 z-[5] bg-black/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="absolute top-0 left-0 bottom-0 w-[320px] bg-[#0a0c11]/95 backdrop-blur-[20px] border-r border-white/10 shadow-[20px_0_50px_rgba(0,0,0,0.5)] z-10 flex flex-col"
            >
              <div className="p-8 border-b border-white/10">
                <h1 className="text-xl font-bold tracking-tight">TAMIL IPTV <span className="text-[#007aff] underline">LIVE</span></h1>
                <p className="text-xs opacity-50 mt-1 uppercase tracking-widest">{channels.length} Channels Available</p>
              </div>

              <div className="flex-1 overflow-y-auto py-4 hide-scrollbar">
                <ul ref={listRef} className="space-y-1">
                  {channels.map((channel: any, index) => {
                    const isSelected = selectedSidebarIndex === index;
                    const isActive = activeChannelIndex === index;
                    const prevChannel = index > 0 ? (channels[index - 1] as any) : null;
                    
                    // working property might be implicitly true if undefined, so check explicit false
                    const isBroken = channel.working === false;
                    const wasBroken = prevChannel ? prevChannel.working === false : false;
                    
                    const showBrokenHeader = !wasBroken && isBroken;
                    const showWorkingHeader = index === 0 && !isBroken;
                    const showBrokenHeaderFirst = index === 0 && isBroken;

                    return (
                      <React.Fragment key={channel.id}>
                        {showWorkingHeader && (
                          <div className="px-6 py-4 mt-2 mb-3 bg-[#0a0c11]/80 backdrop-blur-xl border-b border-white/5 flex items-center gap-3">
                             <div className="flex items-center justify-center p-1.5 rounded bg-green-500/20">
                               <Tv className="w-4 h-4 text-green-400" />
                             </div>
                             <span className="text-[11px] font-bold tracking-[0.2em] uppercase text-white/70">Online Channels</span>
                          </div>
                        )}
                        {(showBrokenHeader || showBrokenHeaderFirst) && (
                          <div className="px-6 py-4 mt-8 mb-3 bg-[#0a0c11]/80 backdrop-blur-xl border-b border-white/5 flex items-center gap-3">
                             <div className="flex items-center justify-center p-1.5 rounded bg-red-500/20">
                               <AlertCircle className="w-4 h-4 text-red-400" />
                             </div>
                             <span className="text-[11px] font-bold tracking-[0.2em] uppercase text-white/70">Offline Channels</span>
                          </div>
                        )}
                        <li 
                          id={`channel-item-${index}`}
                          onClick={() => {
                            setSelectedSidebarIndex(index);
                            setActiveChannelIndex(index);
                            setIsSidebarOpen(false);
                          }}
                          className={cn(
                            "cursor-pointer group flex items-center px-4 py-3 mx-4 my-1 rounded-xl transition-all duration-300 relative overflow-hidden",
                            isSelected 
                              ? "bg-[#007aff]/10 border-transparent shadow-[0_0_20px_rgba(0,122,255,0.05)]" 
                              : isActive 
                                  ? "bg-white/5 border-transparent" 
                                  : "border-transparent hover:bg-white/5",
                            isBroken && !isSelected && !isActive ? "opacity-40 grayscale hover:opacity-70" : ""
                          )}
                        >
                          {isSelected && (
                            <motion.div layoutId="sidebar-active" className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-[#007aff] rounded-r-xl" />
                          )}
                          <span className={cn(
                            "font-mono text-[11px] w-8 flex-shrink-0 font-medium transition-colors",
                            isSelected ? "text-[#007aff]" : "text-white/30 group-hover:text-white/50"
                          )}>
                            {channel.id.toString().padStart(2, '0')}
                          </span>
                          <span className={cn(
                            "font-medium text-[14px] tracking-[0.2px] flex-1 truncate transition-colors pr-2",
                            isSelected ? "text-white font-semibold" : "text-white/80 group-hover:text-white"
                          )}>
                            {channel.name}
                          </span>
                          
                          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center shrink-0">
                            {!isBroken && !isSelected && !isActive && (
                              <Play className="w-3.5 h-3.5 text-white/40" />
                            )}
                          </div>

                          {isBroken && !isSelected && (
                            <span className="bg-red-500/10 text-red-400 border border-red-500/20 text-[9px] uppercase font-bold px-2 py-0.5 rounded ml-2 tracking-wider shrink-0">Offline</span>
                          )}
                          {isActive && (
                            <div className="flex items-center gap-2 ml-2 shrink-0">
                              {!isSelected && <span className="text-[9px] text-[#007aff] uppercase font-bold tracking-widest">Playing</span>}
                              <div className="w-1.5 h-1.5 bg-[#007aff] rounded-full animate-pulse shadow-[0_0_8px_rgba(0,122,255,0.8)]" />
                            </div>
                          )}
                        </li>
                      </React.Fragment>
                    )
                  })}
                </ul>
              </div>
              <div className="p-6 bg-white/5 border-t border-white/10 flex items-center gap-3 mt-auto">
                <div className="w-3 h-3 rounded-full bg-red-600 animate-pulse" />
                <span className="text-sm font-medium tracking-wide">STREAMING 1080p 60FPS</span>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {!isSidebarOpen && showChannelInfo && (
          <motion.button 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={(e) => {
              e.stopPropagation();
              setIsSidebarOpen(true);
              setSelectedSidebarIndex(activeChannelIndex);
            }}
            className="absolute left-8 bottom-8 z-[20] bg-white/10 hover:bg-white/20 backdrop-blur-md p-4 rounded-full transition-all flex items-center justify-center border border-white/5 shadow-[0_10px_30px_rgba(0,0,0,0.5)]"
          >
            <List className="w-8 h-8 text-white/80" />
          </motion.button>
        )}
      </AnimatePresence>

    </div>
  );
}

