import fs from 'fs';

const fileContent = fs.readFileSync('src/App.tsx', 'utf8');

const regex = /const channels = (\[[\s\S]*?\]);/;
const match = fileContent.match(regex);

if (match) {
  const channelsString = match[1];
  
  let channels;
  try {
    channels = eval(channelsString);
  } catch(e) {
    console.error("Error parsing channels:", e);
    process.exit(1);
  }

  const seenNames = new Set();
  const firstOccurrences = [];
  const duplicates = [];

  for (const channel of channels) {
    // Strip trailing numbers (like "Sun TV 2" -> "Sun TV") to group them as well?
    // User said "ஒரு TV channel மீண்டும் மீண்டும் வருகிறது" (A TV channel is coming again and again).
    // Let's just group exact names, or maybe strip numbers if they are variations.
    let nameKey = channel.name.toLowerCase().trim();
    // For safety, let's keep it based on exact names. If there's an issue I can refine it later to strip numbers.
    
    // Actually, sometimes the duplicate is "Sun TV 1", "Sun TV 2", "Sun TV 3".
    // I will consider a channel name base. Let's remove trailing " \d+" if it exists.
    let baseName = nameKey.replace(/\s+\d+$/, '');
    
    if (!seenNames.has(baseName)) {
      seenNames.add(baseName);
      firstOccurrences.push(channel);
    } else {
      duplicates.push(channel);
    }
  }

  const newChannels = [...firstOccurrences, ...duplicates];

  const formattedChannelsArray = newChannels.map((c, i) => {
    return `  { id: ${i + 1}, name: "${c.name}", url: "${c.url}" }`;
  }).join(',\n');

  const newChannelsString = `[\n${formattedChannelsArray}\n]`;
  
  const newFileContent = fileContent.replace(regex, `const channels = ${newChannelsString};`);
  
  fs.writeFileSync('src/App.tsx', newFileContent, 'utf8');
  console.log("Channels sorted successfully! First Count: " + firstOccurrences.length + " Duplicates: " + duplicates.length);
} else {
  console.log("Could not find channels array");
}
