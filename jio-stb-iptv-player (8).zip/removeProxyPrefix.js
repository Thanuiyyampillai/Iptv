import fs from 'fs';

const fileContent = fs.readFileSync('src/App.tsx', 'utf8');
const regex = /const channels = (\[[\s\S]*?\]);/;
const match = fileContent.match(regex);

if (match) {
  const channelsString = match[1];
  let channels;
  try {
    channels = eval(channelsString);
  } catch(e) {
    console.error("Error parsing current channels", e);
    process.exit(1);
  }

  const updatedChannels = channels.map(c => {
    let newUrl = c.url;
    if (newUrl.startsWith('https://anywhere.pwisetthon.com/http')) {
      newUrl = newUrl.replace('https://anywhere.pwisetthon.com/', '');
    }
    return { ...c, url: newUrl };
  });

  const formattedChannelsArray = updatedChannels.map((c) => {
    return `  { id: ${c.id}, name: "${c.name}", url: "${c.url}" }`;
  }).join(',\n');

  const newChannelsString = `[\n${formattedChannelsArray}\n]`;
  const newFileContent = fileContent.replace(regex, `const channels = ${newChannelsString};`);
  
  fs.writeFileSync('src/App.tsx', newFileContent, 'utf8');
  console.log('Removed anywhere.pwisetthon.com prefixes');
} else {
  console.log("Could not find channels config");
}
