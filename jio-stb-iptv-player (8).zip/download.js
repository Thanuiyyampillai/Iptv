import fs from 'fs';

async function main() {
  const url = 'https://raw.githubusercontent.com/amazeyourself/tamil-local-iptv/refs/heads/main/channels.m3u';
  try {
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.text();
      fs.writeFileSync('part8.m3u', data, 'utf8');
      console.log(`Downloaded ${data.length} bytes to part8.m3u`);
    } else {
      console.log("Fetch failed", res.status);
    }
  } catch(e) {
    console.log(e);
  }
}
main();
