import fs from 'fs';

async function main() {
  const url = 'https://api.github.com/repos/amazeyourself/tamil-local-iptv/contents/';
  try {
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      console.log(data.map(f => f.name));
    } else {
      console.log("Fetch failed", res.status);
    }
  } catch(e) {
    console.log(e);
  }
}
main();
