import fs from 'fs';
import https from 'https';
import http from 'http';

const fileContent = fs.readFileSync('src/App.tsx', 'utf8');
const regex = /const channels = (\[[\s\S]*?\]);/;
const match = fileContent.match(regex);

if (!match) {
  console.error("Could not find channels");
  process.exit(1);
}

let channels;
try {
  channels = eval(match[1]);
} catch (e) {
  console.error("Error parsing channels", e);
  process.exit(1);
}

// User-Agent to mimic browser/VLC to prevent getting blocked
const headers = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': '*/*'
};

async function checkUrl(urlStr) {
  return new Promise((resolve) => {
    try {
      const parsedUrl = new URL(urlStr);
      const isHttps = parsedUrl.protocol === 'https:';
      const req = (isHttps ? https : http).request({
        method: 'GET',
        hostname: parsedUrl.hostname,
        port: parsedUrl.port,
        path: parsedUrl.pathname + parsedUrl.search,
        timeout: 8000, // 8-second timeout
        headers: headers
      }, (res) => {
        // Many IPTV servers return 403 or 401 if token is missing/expired, or 200 if OK
        // Sometimes 302 redirect. We'll count 200-399 as "likely working or responsive"
        if (res.statusCode >= 200 && res.statusCode < 400) {
          resolve(true);
        } else {
          resolve(false);
        }
        res.destroy(); // stop downloading the stream immediately
      });

      req.on('error', (err) => resolve(false));
      req.on('timeout', () => { req.destroy(); resolve(false); });
      req.end();
    } catch (e) {
      resolve(false);
    }
  });
}

async function main() {
  console.log('Checking ' + channels.length + ' channels...');
  const BATCH_SIZE = 50; // Check 50 at a time
  for (let i = 0; i < channels.length; i += BATCH_SIZE) {
    const batch = channels.slice(i, i + BATCH_SIZE);
    await Promise.all(batch.map(async (c) => {
      c.working = await checkUrl(c.url);
    }));
    console.log(`Checked ${Math.min(i + BATCH_SIZE, channels.length)}/${channels.length}`);
  }
  
  let workingChannels = channels.filter(c => c.working !== false);
  let brokenChannels = channels.filter(c => c.working === false);
  
  // Sort A-Z
  workingChannels.sort((a,b) => a.name.localeCompare(b.name));
  brokenChannels.sort((a,b) => a.name.localeCompare(b.name));
  
  const finalChannels = [...workingChannels, ...brokenChannels];
  
  const formattedChannelsArray = finalChannels.map((c, index) => {
    return `  { id: ${index + 1}, name: "${c.name.replace(/"/g, '\\"')}", url: "${c.url}", working: ${c.working === false ? 'false' : 'true'} }`;
  }).join(',\n');

  const newChannelsString = `[\n${formattedChannelsArray}\n]`;
  const newFileContent = fileContent.replace(regex, `const channels = ${newChannelsString};`);
  
  fs.writeFileSync('src/App.tsx', newFileContent, 'utf8');
  console.log(`Finished! Working: ${workingChannels.length}, Broken: ${brokenChannels.length}`);
}

main();
