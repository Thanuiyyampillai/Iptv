import express from 'express';
import * as http from 'http';
import * as https from 'https';
import { URL } from 'url';
import * as path from 'path';
import { createServer as createViteServer } from 'vite';

const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 100 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 100, rejectUnauthorized: false });

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Utility to handle both HTTP and HTTPS requests dynamically
  const fetchWithRedirects = (req: express.Request, urlStr: string, res: express.Response, redirects = 0) => {
    if (redirects > 5) {
      res.status(502).send('Too many redirects');
      return;
    }

    try {
      const parsedUrl = new URL(urlStr);
      const requestModule = parsedUrl.protocol === 'https:' ? https : http;

      // Make sure we pass typical browser headers to avoid being blocked by simple bot protection
      const options: any = {
        method: 'GET',
        agent: parsedUrl.protocol === 'https:' ? httpsAgent : httpAgent,
        timeout: 10000,
        headers: {
          'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': '*/*',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'identity',
          'Origin': parsedUrl.origin,
          'Referer': parsedUrl.origin + '/'
        }
      };

      if (req.headers.cookie) {
          options.headers['Cookie'] = req.headers.cookie;
      }

      if (req.headers.range) {
         options.headers['Range'] = req.headers.range;
      }

      const proxyReq = requestModule.request(urlStr, options, (proxyRes) => {
        // Handle Redirects
        if ([301, 302, 303, 307, 308].includes(proxyRes.statusCode || 200) && proxyRes.headers.location) {
          let redirectUrl = proxyRes.headers.location;
          if (!redirectUrl.startsWith('http')) {
             redirectUrl = new URL(redirectUrl, urlStr).toString();
          }
          if (proxyRes.headers['set-cookie']) {
            res.setHeader('set-cookie', proxyRes.headers['set-cookie']);
          }
          
          res.redirect(proxyRes.statusCode || 302, `/api/proxy?url=${encodeURIComponent(redirectUrl)}`);
          return;
        }

        res.status(proxyRes.statusCode || 200);
        
        // Allowed CORS headers
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Range');
        res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range');

        const parsedTargetUrl = new URL(urlStr);
        const urlStrLower = urlStr.toLowerCase();
        let isM3u8 = parsedTargetUrl.pathname.toLowerCase().includes('.m3u8') || urlStrLower.includes('.m3u8') || (proxyRes.headers['content-type'] && proxyRes.headers['content-type']?.toLowerCase().includes('mpegurl'));
        if (!isM3u8 && proxyRes.headers['content-type'] === 'application/octet-stream' && urlStrLower.includes('.m3u8')) {
            isM3u8 = true; 
        }

        // Copy critical headers for video streaming
        const headersToCopy = ['content-type', 'content-range', 'accept-ranges', 'cache-control', 'set-cookie'];
        
        // Only safely copy content-length for binary streaming, not for m3u8 which we rewrite
        if (!isM3u8 && proxyRes.headers['content-length']) {
            res.setHeader('content-length', proxyRes.headers['content-length'] as string);
        }

        headersToCopy.forEach(header => {
          if (proxyRes.headers[header]) {
             res.setHeader(header, proxyRes.headers[header] as string);
          }
        });

        console.log(`[PROXY] ${proxyRes.statusCode} ${urlStr.substring(0, 80)}... (isM3u8: ${isM3u8}, contentType: ${proxyRes.headers['content-type']})`);

        if (isM3u8) {
          let body = '';
          proxyRes.on('data', chunk => body += chunk);
          proxyRes.on('end', () => {
            const lines = body.split('\n');
            const modifiedLines = lines.map(line => {
              const trimmed = line.trim();
              if (!trimmed) return line; // keep empty lines

              if (!trimmed.startsWith('#')) {
                // It's a segment or sub-playlist URL
                let absoluteUrl = trimmed;
                if (!trimmed.startsWith('http')) {
                  absoluteUrl = new URL(trimmed, urlStr).toString();
                }
                return `/api/proxy?url=${encodeURIComponent(absoluteUrl)}`;
              }

              if (trimmed.includes('URI="')) {
                return trimmed.replace(/URI="([^"]+)"/g, (match, urlParam) => {
                  let absoluteUrl = urlParam;
                  if (!urlParam.startsWith('http')) {
                    absoluteUrl = new URL(urlParam, urlStr).toString();
                  }
                  return `URI="/api/proxy?url=${encodeURIComponent(absoluteUrl)}"`;
                });
              }

              return line;
            });
            res.send(modifiedLines.join('\n'));
          });
        } else {
          // Just stream video chunks (.ts, .aac, etc) directly
          proxyRes.pipe(res);
        }
      });

      proxyReq.on('timeout', () => {
        proxyReq.destroy();
      });

      proxyReq.on('error', (err) => {
        if (err.message !== 'socket hang up') {
          console.error(`[PROXY ERROR] ${urlStr}: ${err.message}`);
        }
        if (!res.headersSent) {
          res.status(502).send('Error proxying request: ' + err.message);
        } else {
          res.end();
        }
      });

      proxyReq.end();
    } catch (e) {
      console.error('Invalid URL passed to proxy:', urlStr);
      res.status(400).send('Invalid target URL');
    }
  };

  app.get('/api/proxy', (req, res) => {
    const targetUrl = req.query.url as string;
    if (!targetUrl) {
      return res.status(400).send('No URL provided');
    }
    fetchWithRedirects(req, targetUrl, res);
  });

  // Enable preflight requests
  app.options('/api/proxy', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    res.status(200).end();
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // __dirname is not available in ES module context, so we resolve it this way or just use process.cwd()
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
