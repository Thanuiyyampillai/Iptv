import fs from 'fs';

const fileContent = fs.readFileSync('src/App.tsx', 'utf8');
const regex = /const channels = (\[[\s\S]*?\]);/;
const match = fileContent.match(regex);

if (match) {
  const channelsString = match[1];
  let channels;
  try {
    channels = eval(channelsString);
  } catch(e) {
    console.error("Error parsing current channels", e);
    process.exit(1);
  }

  const uniqueChannels = [];
  const seenUrls = new Set();
  const seenBaseNames = new Set();

  for (let i = 0; i < channels.length; i++) {
    const channel = channels[i];
    const rawUrl = channel.url.trim().toLowerCase();
    
    let baseName = channel.name.toLowerCase();
    baseName = baseName.replace(/[^a-z0-9\s]/g, ''); // remove punctuation
    baseName = baseName.replace(/\b(hd|sd|4k|tv|live|plus)\b/g, ' '); // remove common suffixes
    baseName = baseName.replace(/\s*[0-9]+$/, ''); // remove trailing numbers
    baseName = baseName.replace(/\s+/g, ' ').trim(); // squash spaces
    
    // Check both unique URL and unique simplified name (optional, but requested for cleanup earlier)
    // We'll strictly check URL here since user explicitly said "same url link is repeating"
    if (!seenUrls.has(rawUrl)) {
      seenUrls.add(rawUrl);
      uniqueChannels.push(channel);
    }
  }

  // Re-assign IDs properly
  for (let i = 0; i < uniqueChannels.length; i++) {
     uniqueChannels[i].id = i + 1;
  }

  const formattedChannelsArray = uniqueChannels.map((c) => {
    return `  { id: ${c.id}, name: "${c.name}", url: "${c.url}" }`;
  }).join(',\n');

  const newChannelsString = `[\n${formattedChannelsArray}\n]`;
  const newFileContent = fileContent.replace(regex, `const channels = ${newChannelsString};`);
  
  fs.writeFileSync('src/App.tsx', newFileContent, 'utf8');
  console.log(`Updated channels! Total unique URLs: ${uniqueChannels.length}, Removed duplicates: ${channels.length - uniqueChannels.length}`);
} else {
  console.log("Could not find channels config");
}
