import fs from 'fs';

const fileContent = fs.readFileSync('src/App.tsx', 'utf8');
const regex = /const channels = (\[[\s\S]*?\]);/;
const match = fileContent.match(regex);

if (match) {
  const channelsString = match[1];
  let channels;
  try {
    channels = eval(channelsString);
  } catch(e) {
    console.error("Error parsing current channels", e);
    process.exit(1);
  }

  const parts = ['part8.m3u', 'part9.m3u'];
  let newChannelsList = [];

  parts.forEach(part => {
    if (fs.existsSync(part)) {
      const cnt = fs.readFileSync(part, 'utf8');
      const lines = cnt.split('\n');
      let currentName = '';
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.startsWith('#EXTINF')) {
          const nameMatch = line.match(/,(.*)$/);
          if (nameMatch) {
            currentName = nameMatch[1].trim();
          }
        } else if (line.startsWith('http')) {
           if (currentName && line) {
              newChannelsList.push({ name: currentName, url: line });
              currentName = '';
           }
        }
      }
    }
  });

  console.log(`Found ${newChannelsList.length} new channels in parts`);

  const allChannels = [...channels, ...newChannelsList];

  const uniqueChannels = [];
  const duplicateChannels = [];
  const seenUrls = new Set();
  const seenBaseNames = new Set();

  for (let i = 0; i < allChannels.length; i++) {
    const channel = allChannels[i];
    channel.id = i + 1; // Make sure it has an ID, we'll assign it properly later
    const rawUrl = channel.url.trim().toLowerCase();
    
    let baseName = channel.name.toLowerCase();
    baseName = baseName.replace(/[^a-z0-9\s]/g, ''); // remove punctuation
    baseName = baseName.replace(/\b(hd|sd|4k|tv|live|plus)\b/g, ' '); // remove common suffixes
    baseName = baseName.replace(/\s*[0-9]+$/, ''); // remove trailing numbers
    baseName = baseName.replace(/\s+/g, ' ').trim(); // squash spaces
    
    if (!seenUrls.has(rawUrl) && !seenBaseNames.has(baseName)) {
      seenUrls.add(rawUrl);
      seenBaseNames.add(baseName);
      uniqueChannels.push(channel);
    } else {
      duplicateChannels.push(channel);
    }
  }

  const mergedChannels = [...uniqueChannels, ...duplicateChannels];
  
  const formattedChannelsArray = mergedChannels.map((c, i) => {
    return `  { id: ${i + 1}, name: "${c.name}", url: "${c.url}" }`;
  }).join(',\n');

  const newChannelsString = `[\n${formattedChannelsArray}\n]`;
  const newFileContent = fileContent.replace(regex, `const channels = ${newChannelsString};`);
  
  fs.writeFileSync('src/App.tsx', newFileContent, 'utf8');
  console.log(`Updated channels! Total unique: ${uniqueChannels.length}, Duplicates moved to end: ${duplicateChannels.length}. Total: ${mergedChannels.length}`);
} else {
  console.log("Could not find channels config");
}
