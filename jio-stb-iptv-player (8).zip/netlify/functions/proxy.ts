import { Handler } from '@netlify/functions';
import https from 'https';
import http from 'http';

const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 100 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 100, rejectUnauthorized: false });

const proxy: Handler = async (event, context) => {
  const urlStr = event.queryStringParameters?.url;

  if (!urlStr) {
    return {
      statusCode: 400,
      body: 'No URL provided'
    };
  }

  // A helper function wrapped in a promise to handle http/https requests
  const fetchProxy = (targetUrl: string, redirects = 0): Promise<any> => {
    return new Promise((resolve, reject) => {
      if (redirects > 5) {
        resolve({ statusCode: 502, body: 'Too many redirects' });
        return;
      }

      let parsedUrl: URL;
      try {
        parsedUrl = new URL(targetUrl);
      } catch (err) {
        resolve({ statusCode: 400, body: 'Invalid URL' });
        return;
      }

      const requestModule = parsedUrl.protocol === 'https:' ? https : http;

      const options: any = {
        method: event.httpMethod || 'GET',
        agent: parsedUrl.protocol === 'https:' ? httpsAgent : httpAgent,
        headers: {
          'User-Agent': event.headers['user-agent'] || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': '*/*',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'identity',
          'Origin': parsedUrl.origin,
          'Referer': parsedUrl.origin + '/'
        }
      };

      if (event.headers.range) {
        options.headers['Range'] = event.headers.range;
      }

      const req = requestModule.request(targetUrl, options, (res) => {
        // Handle redirect
        if ([301, 302, 303, 307, 308].includes(res.statusCode || 200) && res.headers.location) {
          let redirectUrl = res.headers.location;
          if (!redirectUrl.startsWith('http')) {
            redirectUrl = new URL(redirectUrl, targetUrl).toString();
          }
          resolve(fetchProxy(redirectUrl, redirects + 1));
          return;
        }

        let isM3u8 = parsedUrl.pathname.endsWith('.m3u8') || (res.headers['content-type'] && res.headers['content-type'].includes('mpegurl'));
        
        if (!isM3u8 && res.headers['content-type'] === 'application/octet-stream' && targetUrl.includes('.m3u8')) {
            isM3u8 = true;
        }

        const headers: Record<string, string> = {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, OPTIONS',
          'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Range',
          'Access-Control-Expose-Headers': 'Content-Length, Content-Range'
        };

        const headersToCopy = ['content-type', 'content-length', 'content-range', 'accept-ranges', 'cache-control'];
        headersToCopy.forEach(header => {
          if (res.headers[header]) {
            headers[header] = res.headers[header] as string;
          }
        });

        if (isM3u8) {
          let body = '';
          res.on('data', (chunk) => { body += chunk.toString(); });
          res.on('end', () => {
            const rewrittenBody = body.replace(/^(?!#)(https?:\/\/.+|\/.+|.+)$/gm, (match) => {
              if (match.startsWith('http')) {
                return `/api/proxy?url=${encodeURIComponent(match)}`;
              } else if (match.startsWith('/')) {
                return `/api/proxy?url=${encodeURIComponent(parsedUrl.origin + match)}`;
              } else {
                const basePath = targetUrl.substring(0, targetUrl.lastIndexOf('/') + 1);
                return `/api/proxy?url=${encodeURIComponent(basePath + match)}`;
              }
            });

            headers['Content-Type'] = 'application/vnd.apple.mpegurl';
            delete headers['content-length']; // The length will change after rewriting!
            
            resolve({
              statusCode: res.statusCode || 200,
              headers,
              body: rewrittenBody
            });
          });
        } else {
          // For binary data (.ts files), we need to buffer and return base64
          const chunks: Buffer[] = [];
          res.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
          res.on('end', () => {
             resolve({
                statusCode: res.statusCode || 200,
                headers,
                body: Buffer.concat(chunks).toString('base64'),
                isBase64Encoded: true
             });
          });
        }
      });

      req.on('error', (e) => {
         resolve({ statusCode: 500, body: `Proxy Error: ${e.message}` });
      });
      req.end();
    });
  };

  return await fetchProxy(urlStr);
};

export { proxy as handler };
