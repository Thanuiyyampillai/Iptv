import fs from 'fs';

const fileContent = fs.readFileSync('src/App.tsx', 'utf8');
const regex = /const channels = (\[[\s\S]*?\]);/;
const match = fileContent.match(regex);

if (match) {
  const channelsString = match[1];
  let channels = eval(channelsString);

  const uniqueChannels = [];
  const duplicateChannels = [];
  const seenUrls = new Set();
  const seenBaseNames = new Set();

  for (const channel of channels) {
    const rawUrl = channel.url.trim().toLowerCase();
    
    // Normalize string: lowercase, remove special characters, HD, SD, 4K, TV, LIVE, numbers at end
    let baseName = channel.name.toLowerCase();
    baseName = baseName.replace(/[^a-z0-9\s]/g, ''); // remove punctuation
    baseName = baseName.replace(/\b(hd|sd|4k|tv|live|plus)\b/g, ' '); // remove common suffixes
    baseName = baseName.replace(/\s*[0-9]+$/, ''); // remove trailing numbers
    baseName = baseName.replace(/\s+/g, ' ').trim(); // squash spaces
    
    // e.g., "Sun TV HD 1" -> "sun"
    // "KTV HD" -> "k"
    // "Vijay TV 4K" -> "vijay"

    if (!seenUrls.has(rawUrl) && !seenBaseNames.has(baseName)) {
      seenUrls.add(rawUrl);
      seenBaseNames.add(baseName);
      uniqueChannels.push(channel);
    } else {
      duplicateChannels.push(channel);
    }
  }

  const allChannels = [...uniqueChannels, ...duplicateChannels];
  
  const formattedChannelsArray = allChannels.map((c, i) => {
    return `  { id: ${i + 1}, name: "${c.name}", url: "${c.url}" }`;
  }).join(',\n');

  const newChannelsString = `[\n${formattedChannelsArray}\n]`;
  const newFileContent = fileContent.replace(regex, `const channels = ${newChannelsString};`);
  
  fs.writeFileSync('src/App.tsx', newFileContent, 'utf8');
  console.log(`Cleaned up harder! Unique: ${uniqueChannels.length}, Duplicates moved to end: ${duplicateChannels.length}`);
} else {
  console.log("Could not find channels config");
}
